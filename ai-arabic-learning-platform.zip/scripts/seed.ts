import "dotenv/config";
import { db } from "@/db";
import {
  learnerProfiles,
  lessons as lessonsTable,
  lessonProgress,
  achievements,
  gameSessions,
} from "@/db/schema";
import { sql } from "drizzle-orm";
import { LESSONS } from "@/lib/curriculum";

async function main() {
  console.log("🌱 Seeding نون database…");

  // Wipe (order-safe with CASCADE)
  await db.execute(sql`TRUNCATE TABLE
    learner_achievements, lesson_progress, game_sessions, ai_stories, chat_messages,
    achievements, lessons, learner_profiles, accounts
    RESTART IDENTITY CASCADE`);

  // --- Learners (main + competitors) ---
  await db.insert(learnerProfiles).values([
    {
      name: "سارة",
      avatar: "🦊",
      age: 7,
      level: "beginner",
      xp: 320,
      coins: 145,
      gems: 12,
      hearts: 5,
      streak: 4,
      rank: 1,
      totalWordsLearned: 48,
      lessonsCompleted: 4,
      minutesLearned: 96,
      todayMinutes: 6,
      dailyGoalMinutes: 15,
      curriculum: "uae",
    },
    { name: "أحمد", avatar: "🦁", age: 8, level: "elementary", xp: 980, coins: 320, streak: 12, rank: 4, totalWordsLearned: 120, lessonsCompleted: 11, minutesLearned: 240 },
    { name: "ليلى", avatar: "🦄", age: 7, level: "elementary", xp: 870, coins: 280, streak: 9, rank: 3, totalWordsLearned: 105, lessonsCompleted: 10, minutesLearned: 210 },
    { name: "يوسف", avatar: "🐯", age: 9, level: "intermediate", xp: 760, coins: 210, streak: 6, rank: 3, totalWordsLearned: 88, lessonsCompleted: 9, minutesLearned: 180 },
    { name: "نورة", avatar: "🐼", age: 6, level: "beginner", xp: 240, coins: 90, streak: 2, rank: 1, totalWordsLearned: 30, lessonsCompleted: 3, minutesLearned: 60 },
  ]);

  // --- Lessons from curriculum ---
  await db.insert(lessonsTable).values(
    LESSONS.map((l) => ({
      slug: l.slug,
      unitId: l.unitId,
      unitTitle: l.unitTitle,
      title: l.title,
      subtitle: l.subtitle,
      category: l.category as never,
      order: l.order,
      emoji: l.emoji,
      color: l.color,
      difficulty: l.difficulty,
      xpReward: l.xpReward,
      coinReward: l.coinReward,
      description: l.description,
      words: l.words as never,
      exercises: l.exercises as never,
      curriculum: "uae",
      isFree: true,
    })),
  );

  // --- Achievements ---
  await db.insert(achievements).values([
    { slug: "first-step", title: "البداية الموفقة", description: "أكمل أول درس", emoji: "🌟", goal: 1, metric: "lessons", tier: "bronze" },
    { slug: "streak-7", title: "سلسلة ٧ أيام", description: "تعلّم ٧ أيام متتالية", emoji: "🔥", goal: 7, metric: "streak", tier: "silver" },
    { slug: "reader", title: "قارئ صغير", description: "أكمل ٥ دروس قراءة", emoji: "📖", goal: 5, metric: "reading", tier: "silver" },
    { slug: "words-50", title: "٥٠ كلمة", description: "تعلّم ٥٠ كلمة جديدة", emoji: "🏅", goal: 50, metric: "words", tier: "gold" },
    { slug: "accuracy", title: "دقة عالية", description: "حقق ٩٠٪ في درس", emoji: "🎯", goal: 90, metric: "accuracy", tier: "gold" },
    { slug: "explorer", title: "مستكشف العوالم", description: "جرّب ٥ ألعاب مختلفة", emoji: "🚀", goal: 5, metric: "games", tier: "bronze" },
  ]);

  // --- Seed progress for main learner (first 3 lessons done) ---
  const seeded = await db.select({ id: lessonsTable.id, slug: lessonsTable.slug }).from(lessonsTable).orderBy(lessonsTable.order).limit(3);
  for (const l of seeded) {
    await db.insert(lessonProgress).values({
      learnerId: 1,
      lessonId: l.id,
      completed: true,
      stars: l.slug.includes("animals") ? 3 : 2,
      accuracy: 80 + Math.floor(Math.random() * 18),
      bestAccuracy: 88,
      attempts: 1,
    });
  }

  // --- A few game sessions for flavor ---
  await db.insert(gameSessions).values([
    { learnerId: 2, learnerName: "أحمد", avatar: "🦁", gameType: "quiz", score: 60, accuracy: 92, xpEarned: 60, durationSec: 180 },
    { learnerId: 3, learnerName: "ليلى", avatar: "🦄", gameType: "match", score: 40, accuracy: 88, xpEarned: 40, durationSec: 140 },
  ]);

  console.log("✅ Seed complete: 5 learners, 10 lessons, 6 achievements, progress seeded.");
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("❌ Seed failed:", e);
    process.exit(1);
  });
