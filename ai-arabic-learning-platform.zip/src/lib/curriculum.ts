import type { CurriculumWord, Exercise } from "@/db/schema";

/* ====================================================================
   نون — Curriculum data (UAE-aligned, modular)
   Mirrors the `lessons` table shape so content can live in the DB or
   in code. Add new units / themes here without touching game logic.
   ==================================================================== */

export type Unit = {
  id: number;
  title: string;
  subtitle: string;
  emoji: string;
  color: string;
};

export type LessonSeed = {
  slug: string;
  unitId: number;
  unitTitle: string;
  title: string;
  subtitle: string;
  category: Exercise extends never ? never : string;
  order: number;
  emoji: string;
  color: string;
  difficulty: number;
  xpReward: number;
  coinReward: number;
  description: string;
  words: CurriculumWord[];
  exercises: Exercise[];
};

export const UNITS: Unit[] = [
  { id: 1, title: "الحروف والأصوات", subtitle: "أبجدية عربية ممتعة", emoji: "🔤", color: "#7c3aed" },
  { id: 2, title: "كلماتي الأولى", subtitle: "مفردات يومية", emoji: "🍎", color: "#f59e0b" },
  { id: 3, title: "التشكيل والقراءة", subtitle: "فتحة، ضمة، كسرة", emoji: "✨", color: "#14b8a6" },
  { id: 4, title: "الجمل والنحو", subtitle: "نركّب جملاً", emoji: "🧩", color: "#f43f5e" },
  { id: 5, title: "القراءة والإملاء", subtitle: "أقرأ وأكتب", emoji: "📖", color: "#0ea5e9" },
  { id: 6, title: "تراث الإمارات", subtitle: "هويتنا وثقافتنا", emoji: "🦅", color: "#d97706" },
];

/* ---------- Vocabulary banks by theme ---------- */
export const VOCAB = {
  animals: [
    { ar: "قِطّة", tr: "qiṭṭa", en: "cat", emoji: "🐱" },
    { ar: "كَلب", tr: "kalb", en: "dog", emoji: "🐶" },
    { ar: "أسَد", tr: "asad", en: "lion", emoji: "🦁" },
    { ar: "فيل", tr: "fīl", en: "elephant", emoji: "🐘" },
    { ar: "حِصان", tr: "ḥiṣān", en: "horse", emoji: "🐴" },
    { ar: "طائِر", tr: "ṭāʾir", en: "bird", emoji: "🐦" },
    { ar: "سَمَكَة", tr: "samaka", en: "fish", emoji: "🐟" },
    { ar: "أرنَب", tr: "arnab", en: "rabbit", emoji: "🐰" },
  ],
  colors: [
    { ar: "أحمَر", tr: "aḥmar", en: "red", emoji: "🟥" },
    { ar: "أزرَق", tr: "azraq", en: "blue", emoji: "🟦" },
    { ar: "أخضَر", tr: "akhḍar", en: "green", emoji: "🟩" },
    { ar: "أصفَر", tr: "aṣfar", en: "yellow", emoji: "🟨" },
    { ar: "برتقالي", tr: "burtuqālī", en: "orange", emoji: "🟧" },
    { ar: "بَنَفْسَجي", tr: "banafsajī", en: "purple", emoji: "🟪" },
  ],
  food: [
    { ar: "خُبز", tr: "khubz", en: "bread", emoji: "🍞" },
    { ar: "ماء", tr: "māʾ", en: "water", emoji: "💧" },
    { ar: "تُفّاح", tr: "tuffāḥ", en: "apple", emoji: "🍎" },
    { ar: "حَليب", tr: "ḥalīb", en: "milk", emoji: "🥛" },
    { ar: "تَمر", tr: "tamr", en: "dates", emoji: "🌴" },
    { ar: "موز", tr: "mawz", en: "banana", emoji: "🍌" },
    { ar: "عَسَل", tr: "ʿasal", en: "honey", emoji: "🍯" },
    { ar: "أَرُزّ", tr: "aruzz", en: "rice", emoji: "🍚" },
  ],
  family: [
    { ar: "أَب", tr: "ab", en: "father", emoji: "👨" },
    { ar: "أُمّ", tr: "umm", en: "mother", emoji: "👩" },
    { ar: "أَخ", tr: "akh", en: "brother", emoji: "👦" },
    { ar: "أُخت", tr: "ukht", en: "sister", emoji: "👧" },
    { ar: "جَدّ", tr: "jadd", en: "grandfather", emoji: "👴" },
    { ar: "جَدَّة", tr: "jadda", en: "grandmother", emoji: "👵" },
  ],
  numbers: [
    { ar: "واحِد", tr: "wāḥid", en: "one", emoji: "1️⃣" },
    { ar: "اثنان", tr: "ithnān", en: "two", emoji: "2️⃣" },
    { ar: "ثَلاثة", tr: "thalātha", en: "three", emoji: "3️⃣" },
    { ar: "أَربَعة", tr: "arbaʿa", en: "four", emoji: "4️⃣" },
    { ar: "خَمسَة", tr: "khamsa", en: "five", emoji: "5️⃣" },
  ],
  space: [
    { ar: "شَمْس", tr: "shams", en: "sun", emoji: "☀️" },
    { ar: "قَمَر", tr: "qamar", en: "moon", emoji: "🌙" },
    { ar: "نَجْمَة", tr: "najma", en: "star", emoji: "⭐" },
    { ar: "صاروخ", tr: "sārūkh", en: "rocket", emoji: "🚀" },
    { ar: "كَوْكَب", tr: "kawkab", en: "planet", emoji: "🪐" },
  ],
  uae: [
    { ar: "صَقْر", tr: "saqr", en: "falcon", emoji: "🦅" },
    { ar: "جَمَل", tr: "jamal", en: "camel", emoji: "🐪" },
    { ar: "نَخيلَة", tr: "nakhīla", en: "palm tree", emoji: "🌴" },
    { ar: "قَهوَة", tr: "qahwa", en: "coffee", emoji: "☕" },
    { ar: "بَحْر", tr: "baḥr", en: "sea", emoji: "🌊" },
    { ar: "صَحْراء", tr: "ṣaḥrāʾ", en: "desert", emoji: "🏜️" },
  ],
  body: [
    { ar: "رَأْس", tr: "raʾs", en: "head", emoji: "🧠" },
    { ar: "عَيْن", tr: "ʿayn", en: "eye", emoji: "👁️" },
    { ar: "يَد", tr: "yad", en: "hand", emoji: "✋" },
    { ar: "قَدَم", tr: "qadam", en: "foot", emoji: "🦶" },
    { ar: "أَنْف", tr: "anf", en: "nose", emoji: "👃" },
  ],
};

/* ---------- Exercise factories ---------- */
const shuffle = <T,>(arr: T[]): T[] => [...arr].sort(() => Math.random() - 0.5);

export function buildMatch(words: CurriculumWord[], prompt: string): Exercise {
  const picks = shuffle(words).slice(0, 4);
  return {
    type: "match",
    prompt,
    pairs: picks.map((w) => ({ word: w.ar, emoji: w.emoji })),
  };
}

export function buildMemory(words: CurriculumWord[], prompt: string): Exercise {
  const picks = shuffle(words).slice(0, 4);
  return {
    type: "memory",
    prompt,
    cards: picks.map((w) => ({ word: w.ar, emoji: w.emoji })),
  };
}

export function buildQuiz(words: CurriculumWord[], prompt: string, q: string): Exercise {
  const picks = shuffle(words);
  const target = picks[0];
  const opts = shuffle([target, ...picks.slice(1, 4)]).map((w) => w.ar);
  return {
    type: "quiz",
    prompt,
    question: q.replace("{word}", target.emoji).replace("{en}", target.en),
    options: opts,
    answer: opts.indexOf(target.ar),
  };
}

export function buildListen(words: CurriculumWord[], prompt: string): Exercise {
  const target = shuffle(words)[0];
  const opts = shuffle([target, ...shuffle(words).filter((w) => w.ar !== target.ar).slice(0, 3)]).map(
    (w) => w.ar,
  );
  return {
    type: "listen",
    prompt,
    word: target.ar,
    emoji: target.emoji,
    options: opts,
  };
}

export function buildWordOrder(sentence: string, translation: string, prompt: string): Exercise {
  return { type: "wordorder", prompt, sentence, translation };
}

export function buildSpell(words: CurriculumWord[], prompt: string): Exercise {
  const target = shuffle(words)[0];
  return {
    type: "spell",
    prompt,
    answer: target.ar,
    emoji: target.emoji,
    hint: target.en,
  };
}

/* ---------- Full lesson catalogue ---------- */
export const LESSONS: LessonSeed[] = [
  {
    slug: "letters-alif",
    unitId: 1,
    unitTitle: "الحروف والأصوات",
    title: "حرف الألف",
    subtitle: "أول الحروف",
    category: "letters",
    order: 1,
    emoji: "ا",
    color: "#7c3aed",
    difficulty: 1,
    xpReward: 20,
    coinReward: 10,
    description: "تعرّف على حرف الألف وصوته وكيف نكتبه.",
    words: VOCAB.animals.slice(0, 4),
    exercises: [
      { type: "trace", prompt: "تتبّع حرف الألف", letter: "ا", name: "ألِف" },
      buildQuiz(VOCAB.animals, "أيٌّ من هذه الكلمات يبدأ بهمزة/ألف؟", "أيُّ كلمة تبدأ بالألف؟"),
      buildMatch(VOCAB.animals, "طابِق الصورة بالكلمة"),
    ],
  },
  {
    slug: "letters-baa",
    unitId: 1,
    unitTitle: "الحروف والأصوات",
    title: "حرف الباء",
    subtitle: "بـ بَ بِ بُ",
    category: "letters",
    order: 2,
    emoji: "ب",
    color: "#7c3aed",
    difficulty: 1,
    xpReward: 20,
    coinReward: 10,
    description: "نتعرّف على الباء وبعض كلماتها.",
    words: VOCAB.family.slice(0, 4),
    exercises: [
      { type: "trace", prompt: "تتبّع حرف الباء", letter: "ب", name: "باء" },
      buildMatch(VOCAB.family, "طابِق الكلمة بالصورة"),
      buildQuiz(VOCAB.family, "اختر الكلمة الصحيحة", "ما اسم {en}؟ {word}"),
    ],
  },
  {
    slug: "animals",
    unitId: 2,
    unitTitle: "كلماتي الأولى",
    title: "عالَم الحيوانات",
    subtitle: "قطط، كلاب، أسود!",
    category: "vocabulary",
    order: 3,
    emoji: "🦁",
    color: "#f59e0b",
    difficulty: 1,
    xpReward: 25,
    coinReward: 12,
    description: "تعلّم أسماء الحيوانات بالعربية مع أصواتها.",
    words: VOCAB.animals,
    exercises: [
      buildMatch(VOCAB.animals, "طابِق كل حيوان باسمه"),
      buildMemory(VOCAB.animals, "اقلب البطاقات ووجد الأزواج"),
      buildListen(VOCAB.animals, "استمع واختر الكلمة الصحيحة"),
      buildQuiz(VOCAB.animals, "اختبر نفسك", "ما الحيوان {en}؟ {word}"),
    ],
  },
  {
    slug: "colors",
    unitId: 2,
    unitTitle: "كلماتي الأولى",
    title: "ألوان قوس قزح",
    subtitle: "أحمر، أزرق، أخضر",
    category: "vocabulary",
    order: 4,
    emoji: "🌈",
    color: "#f59e0b",
    difficulty: 1,
    xpReward: 25,
    coinReward: 12,
    description: "تعلّم الألوان الأساسية بالعربية.",
    words: VOCAB.colors,
    exercises: [
      buildMatch(VOCAB.colors, "طابِق اللون"),
      buildMemory(VOCAB.colors, "لعبة الذاكرة"),
      buildQuiz(VOCAB.colors, "تحدي الألوان", "ما لون {en}؟ {word}"),
    ],
  },
  {
    slug: "food",
    unitId: 2,
    unitTitle: "كلماتي الأولى",
    title: "طعامي اللذيذ",
    subtitle: "خبز، تمر، عسل",
    category: "vocabulary",
    order: 5,
    emoji: "🍯",
    color: "#f59e0b",
    difficulty: 2,
    xpReward: 28,
    coinReward: 14,
    description: "كلمات الطعام والشراب اليومية.",
    words: VOCAB.food,
    exercises: [
      buildMatch(VOCAB.food, "طابِق الطعام"),
      buildSpell(VOCAB.food, "أكمل حروف الكلمة"),
      buildListen(VOCAB.food, "استمع واختر"),
      buildQuiz(VOCAB.food, "تحدي الطعام", "ما اسم {en}؟ {word}"),
    ],
  },
  {
    slug: "tashkeel-fatha",
    unitId: 3,
    unitTitle: "التشكيل والقراءة",
    title: "الفتحة",
    subtitle: "بَ — ب صوت الألف",
    category: "tashkeel",
    order: 6,
    emoji: "بَ",
    color: "#14b8a6",
    difficulty: 2,
    xpReward: 30,
    coinReward: 15,
    description: "نتعلّم صوت الفتحة القصير.",
    words: VOCAB.animals,
    exercises: [
      buildQuiz(VOCAB.animals, "أيُّ كلمة فيها فتحة؟", "اقرأ واختر {en} {word}"),
      buildMatch(VOCAB.animals, "طابِق الكلمات"),
      buildListen(VOCAB.animals, "استمع"),
    ],
  },
  {
    slug: "sentences-family",
    unitId: 4,
    unitTitle: "الجمل والنحو",
    title: "جُمل العائلة",
    subtitle: "رَتِّب الكلمات",
    category: "grammar",
    order: 7,
    emoji: "👨‍👩‍👧‍👦",
    color: "#f43f5e",
    difficulty: 3,
    xpReward: 35,
    coinReward: 18,
    description: "تركيب جُمل بسيطة عن العائلة.",
    words: VOCAB.family,
    exercises: [
      buildWordOrder("هذا أبي", "This is my father", "رتّب الكلمات لتكوّن جملة"),
      buildWordOrder("هذه أمي", "This is my mother", "رتّب الكلمات لتكوّن جملة"),
      buildMatch(VOCAB.family, "طابِق أفراد العائلة"),
      buildQuiz(VOCAB.family, "تحدي العائلة", "من هو {en}؟ {word}"),
    ],
  },
  {
    slug: "numbers-1to5",
    unitId: 5,
    unitTitle: "القراءة والإملاء",
    title: "الأرقام ١–٥",
    subtitle: "واحد إلى خمسة",
    category: "spelling",
    order: 8,
    emoji: "5️⃣",
    color: "#0ea5e9",
    difficulty: 2,
    xpReward: 30,
    coinReward: 15,
    description: "كتابة وتهجئة الأرقام.",
    words: VOCAB.numbers,
    exercises: [
      buildSpell(VOCAB.numbers, "تهجئة الرقم"),
      buildMatch(VOCAB.numbers, "طابِق الرقم"),
      buildQuiz(VOCAB.numbers, "تحدي الأرقام", "ما الرقم {en}؟ {word}"),
    ],
  },
  {
    slug: "space",
    unitId: 5,
    unitTitle: "القراءة والإملاء",
    title: "رحلة في الفضاء",
    subtitle: "شمس، قمر، نجوم",
    category: "reading",
    order: 9,
    emoji: "🚀",
    color: "#0ea5e9",
    difficulty: 3,
    xpReward: 35,
    coinReward: 18,
    description: "مفردات الفضاء مع قراءة قصيرة.",
    words: VOCAB.space,
    exercises: [
      buildMatch(VOCAB.space, "طابِق الفضاء"),
      buildMemory(VOCAB.space, "ذاكرة الفضاء"),
      buildListen(VOCAB.space, "استمع للكلمة"),
      buildQuiz(VOCAB.space, "تحدي الفضاء", "ما {en}؟ {word}"),
    ],
  },
  {
    slug: "uae-heritage",
    unitId: 6,
    unitTitle: "تراث الإمارات",
    title: "هوية الإمارات",
    subtitle: "صقر، جمل، نخلة",
    category: "culture",
    order: 10,
    emoji: "🦅",
    color: "#d97706",
    difficulty: 3,
    xpReward: 40,
    coinReward: 20,
    description: "مفردات التراث والهوية الوطنية الإماراتية.",
    words: VOCAB.uae,
    exercises: [
      buildMatch(VOCAB.uae, "طابِق رموز التراث"),
      buildMemory(VOCAB.uae, "ذاكرة التراث"),
      buildQuiz(VOCAB.uae, "تحدي الهوية", "ما {en}؟ {word}"),
      buildListen(VOCAB.uae, "استمع لرمز التراث"),
    ],
  },
];

export function lessonBySlug(slug: string) {
  return LESSONS.find((l) => l.slug === slug);
}
