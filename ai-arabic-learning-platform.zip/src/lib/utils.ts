/* Shared helpers: gamification math, formatting, DB seed helpers */

export function cn(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

/* XP / level system: 100, 250, 450, 700, 1000... */
const LEVEL_THRESHOLDS = [0, 100, 250, 450, 700, 1000, 1400, 1900, 2500, 3200, 4000];

export function levelFromXp(xp: number) {
  let level = 1;
  for (let i = 0; i < LEVEL_THRESHOLDS.length; i++) {
    if (xp >= LEVEL_THRESHOLDS[i]) level = i + 1;
  }
  const current = LEVEL_THRESHOLDS[level - 1] ?? 0;
  const next = LEVEL_THRESHOLDS[level] ?? current + 600;
  const into = xp - current;
  const span = next - current;
  return { level, current, next, into, span, pct: Math.min(100, Math.round((into / span) * 100)) };
}

export const RANK_TITLES = [
  "مبتدئ",
  "مكتشف",
  "مغامر",
  "متمكّن",
  "بارع",
  "خبير",
  "حكيم",
  "أسطورة",
];

export function rankTitle(level: number) {
  return RANK_TITLES[Math.min(level - 1, RANK_TITLES.length - 1)];
}

export function fmt(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  return String(n);
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export const AVATARS = ["🦊", "🐼", "🦁", "🐯", "🦉", "🐸", "🦄", "🐰", "🐨", "🐧"];

export const MASCOT = "🦊"; // نون the fox mascot
