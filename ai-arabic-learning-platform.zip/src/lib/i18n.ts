/* ====================================================================
   نون — Internationalization (8 interface languages)
   Arabic content taught stays in Arabic; this controls the UI chrome.
   ==================================================================== */

export type Lang = "ar" | "en" | "fr" | "hi" | "ur" | "zh" | "ru" | "es";

export const LANGUAGES: { code: Lang; label: string; flag: string; dir: "rtl" | "ltr" }[] = [
  { code: "ar", label: "العربية", flag: "🇦🇪", dir: "rtl" },
  { code: "en", label: "English", flag: "🇬🇧", dir: "ltr" },
  { code: "fr", label: "Français", flag: "🇫🇷", dir: "ltr" },
  { code: "hi", label: "हिन्दी", flag: "🇮🇳", dir: "ltr" },
  { code: "ur", label: "اردو", flag: "🇵🇰", dir: "rtl" },
  { code: "zh", label: "中文", flag: "🇨🇳", dir: "ltr" },
  { code: "ru", label: "Русский", flag: "🇷🇺", dir: "ltr" },
  { code: "es", label: "Español", flag: "🇪🇸", dir: "ltr" },
];

export const dirOf = (lang: Lang): "rtl" | "ltr" =>
  LANGUAGES.find((l) => l.code === lang)?.dir ?? "rtl";

type Dict = Record<string, string>;

const ar: Dict = {
  "nav.home": "الرئيسية",
  "nav.learn": "تعلّم",
  "nav.tutor": "المعلّم الذكي",
  "nav.stories": "مولّد القصص",
  "nav.shop": "المتجر",
  "nav.leaderboard": "المتصدرون",
  "nav.parent": "ولي الأمر",
  "nav.teacher": "المعلّم",
  "nav.dashboard": "لوحتي",
  "hero.badge": "مدعوم بالذكاء الاصطناعي · متوافق مع المنهج الإماراتي",
  "hero.title": "عالم العربية الذكي للأطفال",
  "hero.subtitle":
    "تتعلّم العربية عبر قصص وألعاب تفاعلية، مع معلّم ذكي يتكيّف مع مستوى كل طفل ويصحّح نُطقه. مغامرة ممتعة تبدأ من الحرف وتصل إلى الإبداع.",
  "hero.cta": "ابدأ التعلّم مجاناً",
  "hero.cta2": "للمدارس وأولياء الأمور",
  "hero.stat1": "طفل سعيد",
  "hero.stat2": "لعبة تعليمية",
  "hero.stat3": "دقة النطق",
  "common.start": "ابدأ",
  "common.continue": "أكمل التعلّم",
  "common.next": "التالي",
  "common.check": "تحقّق",
  "common.correct": "أحسنت! إجابة صحيحة",
  "common.wrong": "حاول مرة أخرى",
  "common.skip": "تخطّي",
  "common.xp": "نقاط",
  "common.coins": "عملات",
  "common.gems": "جواهر",
  "common.hearts": "قلوب",
  "common.streak": "أيام متتالية",
  "common.level": "المستوى",
  "common.daily": "الهدف اليومي",
  "common.completed": "مكتمل",
  "common.locked": "مقفل",
  "common.minutes": "دقيقة",
  "common.replay": "إعادة",
};

const en: Dict = {
  "nav.home": "Home",
  "nav.learn": "Learn",
  "nav.tutor": "AI Tutor",
  "nav.stories": "Story Lab",
  "nav.shop": "Shop",
  "nav.leaderboard": "Leaderboard",
  "nav.parent": "Parent",
  "nav.teacher": "Teacher",
  "nav.dashboard": "My Board",
  "hero.badge": "AI-powered · Aligned with the UAE curriculum",
  "hero.title": "The smart Arabic world for kids",
  "hero.subtitle":
    "Learn Arabic through interactive stories and games, with an AI tutor that adapts to each child and corrects pronunciation. A joyful journey from the first letter to creative expression.",
  "hero.cta": "Start learning free",
  "hero.cta2": "For schools & parents",
  "hero.stat1": "Happy learners",
  "hero.stat2": "Educational games",
  "hero.stat3": "Pronunciation accuracy",
  "common.start": "Start",
  "common.continue": "Continue learning",
  "common.next": "Next",
  "common.check": "Check",
  "common.correct": "Well done! Correct",
  "common.wrong": "Try again",
  "common.skip": "Skip",
  "common.xp": "XP",
  "common.coins": "Coins",
  "common.gems": "Gems",
  "common.hearts": "Hearts",
  "common.streak": "Day streak",
  "common.level": "Level",
  "common.minutes": "min",
  "common.daily": "Daily goal",
  "common.completed": "Completed",
  "common.locked": "Locked",
  "common.replay": "Replay",
};

const fr: Dict = {
  ...en,
  "nav.home": "Accueil",
  "nav.learn": "Apprendre",
  "nav.tutor": "Tuteur IA",
  "nav.stories": "Histoires",
  "nav.shop": "Boutique",
  "nav.leaderboard": "Classement",
  "nav.parent": "Parent",
  "nav.teacher": "Enseignant",
  "hero.badge": "Propulsé par l'IA · Aligné sur le programme des EAU",
  "hero.title": "Le monde arabe intelligent pour enfants",
  "hero.cta": "Commencer gratuitement",
};

const hi: Dict = {
  ...en,
  "nav.home": "होम",
  "nav.learn": "सीखें",
  "nav.tutor": "एआई शिक्षक",
  "nav.stories": "कहानियाँ",
  "nav.shop": "स्टोर",
  "nav.leaderboard": "लीडरबोर्ड",
  "hero.badge": "एआई संचालित · यूएई पाठ्यक्रम के अनुरूप",
  "hero.title": "बच्चों के लिए स्मार्ट अरबी दुनिया",
  "hero.cta": "मुफ़्त में शुरू करें",
};

const ur: Dict = {
  ...en,
  "nav.home": "ہوم",
  "nav.learn": "سیکیں",
  "nav.tutor": "اے آئی ٹیوٹر",
  "nav.stories": "کہانیاں",
  "nav.shop": "اسٹور",
  "nav.leaderboard": "لیڈر بورڈ",
  "hero.badge": "اے آئی پر مبنی · یو اے ای نصاب کے مطابق",
  "hero.title": "بچوں کے لیے سمجھدار عربی دنیا",
  "hero.cta": "مفت شروع کریں",
};

const zh: Dict = {
  ...en,
  "nav.home": "首页",
  "nav.learn": "学习",
  "nav.tutor": "AI 导师",
  "nav.stories": "故事",
  "nav.shop": "商店",
  "nav.leaderboard": "排行榜",
  "hero.badge": "AI 驱动 · 符合阿联酋课程",
  "hero.title": "为孩子打造的智能阿拉伯语世界",
  "hero.cta": "免费开始",
};

const ru: Dict = {
  ...en,
  "nav.home": "Главная",
  "nav.learn": "Учиться",
  "nav.tutor": "ИИ-наставник",
  "nav.stories": "Сказки",
  "nav.shop": "Магазин",
  "nav.leaderboard": "Рейтинг",
  "hero.badge": "На базе ИИ · По программе ОАЭ",
  "hero.title": "Умный мир арабского для детей",
  "hero.cta": "Начать бесплатно",
};

const es: Dict = {
  ...en,
  "nav.home": "Inicio",
  "nav.learn": "Aprender",
  "nav.tutor": "Tutor IA",
  "nav.stories": "Cuentos",
  "nav.shop": "Tienda",
  "nav.leaderboard": "Ranking",
  "hero.badge": "Con IA · Alineado con el programa de EAU",
  "hero.title": "El mundo árabe inteligente para niños",
  "hero.cta": "Empezar gratis",
};

const DICTS: Record<Lang, Dict> = { ar, en, fr, hi, ur, zh, ru, es };

export function makeT(lang: Lang) {
  const dict = DICTS[lang] ?? ar;
  return (key: string): string => dict[key] ?? en[key] ?? ar[key] ?? key;
}
