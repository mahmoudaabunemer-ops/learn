/* ====================================================================
   نون — AI Service Layer
   Pluggable LLM gateway (Gemini / OpenAI / Anthropic) with rich,
   education-grade fallbacks so every feature works with or without
   API keys. Swap models via env without touching feature code.
   ==================================================================== */

type Provider = "gemini" | "openai" | "anthropic";

function pickProvider(): { provider: Provider; key: string } | null {
  if (process.env.GEMINI_API_KEY) return { provider: "gemini", key: process.env.GEMINI_API_KEY };
  if (process.env.OPENAI_API_KEY) return { provider: "openai", key: process.env.OPENAI_API_KEY };
  if (process.env.ANTHROPIC_API_KEY) return { provider: "anthropic", key: process.env.ANTHROPIC_API_KEY };
  return null;
}

async function llmText(system: string, user: string): Promise<string | null> {
  const p = pickProvider();
  if (!p) return null;
  try {
    if (p.provider === "gemini") {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${p.key}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: system }] },
            contents: [{ role: "user", parts: [{ text: user }] }],
            generationConfig: { temperature: 0.8, maxOutputTokens: 800 },
          }),
        },
      );
      const data = await res.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      return typeof text === "string" ? text : null;
    }
    if (p.provider === "openai") {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${p.key}` },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          temperature: 0.8,
          max_tokens: 800,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      });
      const data = await res.json();
      return data?.choices?.[0]?.message?.content ?? null;
    }
    // anthropic
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": p.key,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-3-5-sonnet-latest",
        max_tokens: 800,
        system,
        messages: [{ role: "user", content: user }],
      }),
    });
    const data = await res.json();
    return data?.content?.[0]?.text ?? null;
  } catch {
    return null;
  }
}

function safeJson<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start === -1 || end === -1) return fallback;
    return JSON.parse(raw.slice(start, end + 1)) as T;
  } catch {
    return fallback;
  }
}

/* ------------------------------------------------------------------ */
/* 1) Smart Tutor — conversational Arabic teacher                       */
/* ------------------------------------------------------------------ */
export async function tutorReply(message: string, history: { role: string; content: string }[]) {
  const sys =
    "أنت 'معلّم نون'، معلّم ذكاء اصطناعي لطيف ومشجّع يعلّم الأطفال والمبتدئين اللغة العربية. " +
    "أجب بالعربية الفصحى المبسّطة، بدفء وتشجيع، واستخدم الرموز التعبيرية باعتدال. " +
    "إن سأل الطفل عن معنى كلمة أو نطقها، اشرح ببساطة وأعطِ مثالاً. اجعل إجابتك قصيرة (سطرين إلى أربعة).";
  const convo = history.slice(-6).map((m) => `${m.role === "learner" ? "الطالب" : "المعلّم"}: ${m.content}`).join("\n");
  const live = await llmText(sys, `${convo}\nالطالب: ${message}\nالمعلّم:`);
  if (live) return { text: live.trim(), source: "ai" as const };
  return { text: fallbackTutor(message), source: "local" as const };
}

function fallbackTutor(message: string): string {
  const m = message.toLowerCase();
  if (/(مرحبا|السلام|اهلا|أهلا|hi|hello|هلا)/.test(message))
    return "أهلاً وسهلاً بك في عالم نون! 🦊 أنا معلّمك الذكي. جاهز لنبدأ مغامرة العربية؟ اكتب أي كلمة تريد أن نتعلّمها معاً!";
  if (/(كيف حالك|كيفك|اخبارك)/.test(message))
    return "بخير والحمد لله، وأنا متحمّس جداً لمساعدتك اليوم! 😄 ما الذي تريد أن نتعلّمه؟ الحروف، المفردات، أم جملة جميلة؟";
  if (/(شكر|thank)/.test(message)) return "العفو يا بطل! ⭐ أنا فخور بك. استمر، وكل خطوة تقرّبك من إتقان العربية.";
  if (/(معنى|تعني|معناها|what does)/.test(message)) {
    const word = message.replace(/.*(معنى|تعني|معناها|what does)/, "").replace(/.*mean/i, "").trim();
    return word
      ? `كلمة «${word}» جميلة! دعنا نتعلّمها خطوة بخطوة: نقرؤها، نكتبها، ثم نستخدمها في جملة. هل تريد أن نجرّب؟ ✍️`
      : "اسألني عن أي كلمة وسأشرح معناها ببساطة وأعطيك مثالاً. 📚";
  }
  if (/(نطق|كيف انطق|how to pronounce|صوت)/.test(message))
    return "النطق الصحيح سرّ جمال العربية! 🎤 خذ نفساً، انطق ببطء، وراقب مخارج الحروف. جرّب أن تكرّر الكلمة ثلاث مرات بصوت واضح.";
  if (/(مساعده|ساعدني|help|صعب|ما افهم)/.test(message))
    return "لا تقلق إطلاقاً! 💪 كل خبير كان مبتدئاً يوماً. سنقسّم الفكرة إلى أجزاء صغيرة سهلة. أخبرني بالضبط ما الذي يشغلك وسنبسّطه معاً.";
  return `سؤال رائع! 🌟 دعنا نكتشف إجابته معاً. في العربية كل حرف له صوت وقصة. هل تريد أن نتعلّم كلمة جديدة الآن؟`;
}

/* ------------------------------------------------------------------ */
/* 2) Story Generator — personalised Arabic stories                     */
/* ------------------------------------------------------------------ */
export type StoryResult = {
  title: string;
  paragraphs: string[];
  vocabulary: { ar: string; tr: string; en: string; emoji: string }[];
  questions: { question: string; options: string[]; answer: number }[];
  source: "ai" | "local";
};

const STORY_TEMPLATES: Record<string, (words: string[]) => Omit<StoryResult, "source">> = {
  forest: (w) => ({
    title: "مغامرة الثعلب في الغابة",
    paragraphs: [
      `في يومٍ مشمس، خرج الثعلبُ الصغيرُ ليتجوّل في الغابة. رأى ${w[0] ?? "قطة"} صغيرة تجلس تحت شجرة.`,
      `قال الثعلب: «مرحباً يا ${w[0] ?? "صديقي"}! هل تريد أن نلعب؟» ففرِح ${w[0] ?? "الصديق"} كثيراً.`,
      `لعبا معاً حتى غروب الشمس، ثم عاد كلٌّ منهما إلى بيته سعيداً. تعلّما أن الصداقة أجمل كنز.`,
    ],
    vocabulary: [
      { ar: "غابة", tr: "ghāba", en: "forest", emoji: "🌳" },
      { ar: "ثعلب", tr: "thaʿlab", en: "fox", emoji: "🦊" },
      { ar: "شمس", tr: "shams", en: "sun", emoji: "☀️" },
    ],
    questions: [
      { question: "أين خرج الثعلب يتجوّل؟", options: ["الغابة", "البحر", "المدينة"], answer: 0 },
      { question: "ماذا تعلّما في النهاية؟", options: ["اللعب", "الصداقة", "النوم"], answer: 1 },
    ],
  }),
  space: (w) => ({
    title: "رائد الفضاء الصغير",
    paragraphs: [
      `حلمت الطفلةُ بأن تطير إلى الفضاء. ركبت صاروخاً صغيراً وانطلقت نحو ${w[0] ?? "القمر"}.`,
      `في الفضاء رأت نجومًا تلمع وقمراً منيرًا. قالت: «ما أجمل الكون!» وابتسمت بسعادة.`,
      `عادت إلى الأرض تحمل ذكرياتٍ ساطعة كالنجوم، وعاهدت نفسها أن تتعلّم أكثر كل يوم.`,
    ],
    vocabulary: [
      { ar: "صاروخ", tr: "sārūkh", en: "rocket", emoji: "🚀" },
      { ar: "قمر", tr: "qamar", en: "moon", emoji: "🌙" },
      { ar: "نجم", tr: "najm", en: "star", emoji: "⭐" },
    ],
    questions: [
      { question: "إلى أين انطلقت الطفلة؟", options: ["البحر", "الفضاء", "الجبل"], answer: 1 },
      { question: "ماذا رأت في الفضاء؟", options: ["نجوم", "أسماك", "أشجار"], answer: 0 },
    ],
  }),
  uae: (w) => ({
    title: "يوم في صحراء الإمارات",
    paragraphs: [
      `خرج الجدّ مع أحفاده إلى الصحراء. ركبوا ${w[0] ?? "الجمل"} ومشوا بين كثبان الرمل الذهبية.`,
      `جلسوا تحت النخيل، وشربوا القهوة العربية، ورأوا الصقر يحلّق عالياً في السماء الصافية.`,
      `قال الجدّ: «هذه أرضنا وتراثنا، احفظوا لغتكم وهويتكم.» فحفظ الأحفاط ذلك الدرس الجميل.`,
    ],
    vocabulary: [
      { ar: "جمل", tr: "jamal", en: "camel", emoji: "🐪" },
      { ar: "صقر", tr: "saqr", en: "falcon", emoji: "🦅" },
      { ar: "نخلة", tr: "nakhla", en: "palm", emoji: "🌴" },
    ],
    questions: [
      { question: "ماذا ركبوا في الصحراء؟", options: ["الجمل", "الطائرة", "القطار"], answer: 0 },
      { question: "ماذا شربوا؟", options: ["قهوة عربية", "عصير", "شاي"], answer: 0 },
    ],
  }),
};

export async function generateStory(opts: {
  theme: string;
  level: string;
  age: number;
  words: string[];
}): Promise<StoryResult> {
  const fallback = (STORY_TEMPLATES[opts.theme] ?? STORY_TEMPLATES.forest)(opts.words);
  const live = await llmText(
    "أنت كاتب قصص أطفال خبير في اللغة العربية. أعد JSON فقط.",
    `اكتب قصة قصيرة لطيفة بموضوع «${opts.theme}» لمستوى ${opts.level} وعمر ${opts.age} سنوات، ` +
      `باستخدام كلمات: ${opts.words.join("، ")}. ` +
      `أعِد JSON بصيغة: {"title":"...","paragraphs":["..."],"vocabulary":[{"ar":"...","tr":"...","en":"...","emoji":"..."}],"questions":[{"question":"...","options":["..."],"answer":0}]}`,
  );
  const parsed = safeJson<StoryResult | null>(live, null);
  if (parsed?.title && Array.isArray(parsed.paragraphs)) return { ...parsed, source: "ai" };
  return { ...fallback, source: "local" };
}

/* ------------------------------------------------------------------ */
/* 3) Performance analysis — adaptive learning insights                 */
/* ------------------------------------------------------------------ */
export type AnalysisResult = {
  summary: string;
  strengths: string[];
  focus: { area: string; tip: string }[];
  plan: string[];
  source: "ai" | "local";
};

export async function analyzePerformance(stats: {
  level: string;
  xp: number;
  streak: number;
  minutesLearned: number;
  lessonsCompleted: number;
  accuracy: number;
  weakest: string;
  best: string;
}): Promise<AnalysisResult> {
  const live = await llmText(
    "أنت محلّل تعلّم ذكي يكتب تقارير مختصرة ومحفّزة لولي الأمر بالعربية. أعِد JSON فقط.",
    `حلّل أداء طالب: المستوى ${stats.level}, نقاط الخبرة ${stats.xp}, الأيام المتتالية ${stats.streak}, ` +
      `دقائق التعلّم ${stats.minutesLearned}, دروس مكتملة ${stats.lessonsCompleted}, الدقة ${stats.accuracy}%, ` +
      `أضعف مجال: ${stats.weakest}, أقوى مجال: ${stats.best}. ` +
      `أعِد JSON: {"summary":"...","strengths":["..."],"focus":[{"area":"...","tip":"..."}],"plan":["..."]}`,
  );
  const parsed = safeJson<AnalysisResult | null>(live, null);
  if (parsed?.summary) return { ...parsed, source: "ai" };
  return {
    summary: `طفلك في المستوى ${stats.level} وقد أكمل ${stats.lessonsCompleted} دروسًا بدقة ${stats.accuracy}% وسلسلة ${stats.streak} يومًا متتاليًا. التقدّم واعد! 🌱`,
    strengths: [
      `تميّز في مجال: ${stats.best}`,
      stats.streak >= 3 ? "التزام يومي ممتاز بالتعلّم" : "بداية جيدة يمكن البناء عليها",
      stats.accuracy >= 80 ? "دقة عالية في الإجابات" : "تحسّن ملحوظ في الفهم",
    ],
    focus: [
      { area: stats.weakest, tip: "خصّص ١٠ دقائق يوميًا لتمارين إضافية في هذا المجال" },
      { area: "القراءة بصوت عالٍ", tip: "اقرأ مع طفلك قصة قصيرة كل مساء" },
    ],
    plan: [
      "مراجعة ٥ كلمات جديدة كل يوم",
      `تركيز هذا الأسبوع على: ${stats.weakest}`,
      "إنجاز ٣ دروس على الأقل أسبوعيًا",
    ],
    source: "local",
  };
}

/* ------------------------------------------------------------------ */
/* 4) Pronunciation feedback (simulated speech analysis)                */
/* ------------------------------------------------------------------ */
export function pronunciationFeedback(target: string, _attempt: string) {
  const tips = [
    "انطق الحروف من مخارجها الصحيحة ببطء أولاً ثم تسارع تدريجيًا.",
    "راقب الحركات: الفتحة والضمة والكسرة تغيّر المعنى!",
    "خذ نَفَسًا كافيًا قبل الجمل الطويلة ووقف عند علامات الترقيم.",
  ];
  const score = 70 + Math.floor(Math.random() * 28);
  return {
    score,
    level: score >= 90 ? "ممتاز" : score >= 80 ? "جيد جدًا" : "جيد",
    tips: [tips[Math.floor(Math.random() * tips.length)]],
  };
}

export const AI_MODELS = ["Gemini 1.5 Flash", "GPT-4o mini", "Claude 3.5 Sonnet", "Whisper STT", "TTS Arabic"];
