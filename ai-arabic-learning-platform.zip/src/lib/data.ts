import { db } from "@/db";
import {
  learnerProfiles,
  lessons as lessonsTable,
  lessonProgress,
  gameSessions,
  aiStories,
  learnerAchievements,
  achievements,
} from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";
import { LESSONS, type LessonSeed } from "@/lib/curriculum";
import { MASCOT } from "@/lib/utils";

/* Unified lesson shape used across the UI */
export type AppLesson = {
  id: number;
  slug: string;
  unitId: number;
  unitTitle: string;
  title: string;
  subtitle: string | null;
  category: string;
  order: number;
  emoji: string;
  color: string;
  difficulty: number;
  xpReward: number;
  coinReward: number;
  description: string | null;
  words: LessonSeed["words"];
  exercises: LessonSeed["exercises"];
};

export type Learner = {
  id: number;
  name: string;
  avatar: string;
  age: number;
  level: string;
  xp: number;
  coins: number;
  gems: number;
  hearts: number;
  streak: number;
  rank: number;
  totalWordsLearned: number;
  lessonsCompleted: number;
  minutesLearned: number;
  todayMinutes: number;
  dailyGoalMinutes: number;
};

export const DEFAULT_LEARNER: Learner = {
  id: 1,
  name: "سارة",
  avatar: MASCOT,
  age: 7,
  level: "beginner",
  xp: 320,
  coins: 145,
  gems: 12,
  hearts: 5,
  streak: 4,
  rank: 1,
  totalWordsLearned: 48,
  lessonsCompleted: 4,
  minutesLearned: 96,
  todayMinutes: 6,
  dailyGoalMinutes: 15,
};

const fallbackLessons: AppLesson[] = LESSONS.map((l, i) => ({
  id: i + 1,
  slug: l.slug,
  unitId: l.unitId,
  unitTitle: l.unitTitle,
  title: l.title,
  subtitle: l.subtitle,
  category: l.category,
  order: l.order,
  emoji: l.emoji,
  color: l.color,
  difficulty: l.difficulty,
  xpReward: l.xpReward,
  coinReward: l.coinReward,
  description: l.description,
  words: l.words,
  exercises: l.exercises,
}));

export async function getLearner(): Promise<Learner> {
  try {
    const [row] = await db
      .select()
      .from(learnerProfiles)
      .orderBy(learnerProfiles.id)
      .limit(1);
    if (!row) return DEFAULT_LEARNER;
    return {
      id: row.id,
      name: row.name,
      avatar: row.avatar,
      age: row.age,
      level: row.level,
      xp: row.xp,
      coins: row.coins,
      gems: row.gems,
      hearts: row.hearts,
      streak: row.streak,
      rank: row.rank,
      totalWordsLearned: row.totalWordsLearned,
      lessonsCompleted: row.lessonsCompleted,
      minutesLearned: row.minutesLearned,
      todayMinutes: row.todayMinutes,
      dailyGoalMinutes: row.dailyGoalMinutes,
    };
  } catch {
    return DEFAULT_LEARNER;
  }
}

export async function getLessons(): Promise<AppLesson[]> {
  try {
    const rows = await db.select().from(lessonsTable).orderBy(lessonsTable.unitId, lessonsTable.order);
    if (rows.length === 0) return fallbackLessons;
    return rows as unknown as AppLesson[];
  } catch {
    return fallbackLessons;
  }
}

export type Progress = {
  lessonId: number;
  completed: boolean;
  stars: number;
  accuracy: number;
};

export async function getProgressMap(learnerId: number): Promise<Record<number, Progress>> {
  try {
    const rows = await db
      .select()
      .from(lessonProgress)
      .where(eq(lessonProgress.learnerId, learnerId));
    const map: Record<number, Progress> = {};
    for (const r of rows) {
      map[r.lessonId] = {
        lessonId: r.lessonId,
        completed: r.completed,
        stars: r.stars,
        accuracy: r.accuracy,
      };
    }
    return map;
  } catch {
    return {};
  }
}

export type LeaderRow = {
  learnerId: number;
  name: string;
  avatar: string;
  xp: number;
  lessonsCompleted: number;
};

export async function getLeaderboard(): Promise<LeaderRow[]> {
  try {
    const rows = await db
      .select({
        learnerId: learnerProfiles.id,
        name: learnerProfiles.name,
        avatar: learnerProfiles.avatar,
        xp: learnerProfiles.xp,
        lessonsCompleted: learnerProfiles.lessonsCompleted,
      })
      .from(learnerProfiles)
      .orderBy(desc(learnerProfiles.xp))
      .limit(20);
    if (rows.length === 0) return FALLBACK_LEADERBOARD;
    return rows;
  } catch {
    return FALLBACK_LEADERBOARD;
  }
}

const FALLBACK_LEADERBOARD: LeaderRow[] = [
  { learnerId: 2, name: "أحمد", avatar: "🦁", xp: 980, lessonsCompleted: 11 },
  { learnerId: 3, name: "ليلى", avatar: "🦄", xp: 870, lessonsCompleted: 10 },
  { learnerId: 4, name: "يوسف", avatar: "🐯", xp: 760, lessonsCompleted: 9 },
  { learnerId: 1, name: "سارة", avatar: "🦊", xp: 320, lessonsCompleted: 4 },
  { learnerId: 5, name: "نورة", avatar: "🐼", xp: 240, lessonsCompleted: 3 },
];

export async function getRecentStories(learnerId: number) {
  try {
    const rows = await db
      .select()
      .from(aiStories)
      .where(eq(aiStories.learnerId, learnerId))
      .orderBy(desc(aiStories.createdAt))
      .limit(6);
    return rows;
  } catch {
    return [];
  }
}

export async function getEarnedAchievements(learnerId: number) {
  try {
    const rows = await db
      .select({
        slug: achievements.slug,
        title: achievements.title,
        description: achievements.description,
        emoji: achievements.emoji,
        tier: achievements.tier,
        earnedAt: learnerAchievements.earnedAt,
      })
      .from(learnerAchievements)
      .innerJoin(achievements, eq(achievements.id, learnerAchievements.achievementId))
      .where(eq(learnerAchievements.learnerId, learnerId))
      .orderBy(desc(learnerAchievements.earnedAt));
    return rows;
  } catch {
    return [];
  }
}

export async function getPerformanceStats(learnerId: number) {
  const learner = await getLearner();
  let weakest = "الإملاء";
  let best = "المفردات";
  let accuracy = learner.level === "beginner" ? 78 : 84;
  try {
    const rows = await db
      .select({
        category: lessonsTable.category,
        accuracy: lessonProgress.accuracy,
      })
      .from(lessonProgress)
      .innerJoin(lessonsTable, eq(lessonsTable.id, lessonProgress.lessonId))
      .where(eq(lessonProgress.learnerId, learnerId));
    if (rows.length) {
      const agg: Record<string, { sum: number; n: number }> = {};
      let total = 0;
      for (const r of rows) {
        const k = String(r.category);
        agg[k] = agg[k] || { sum: 0, n: 0 };
        agg[k].sum += r.accuracy;
        agg[k].n += 1;
        total += r.accuracy;
      }
      accuracy = Math.round(total / rows.length);
      const entries = Object.entries(agg).map(([k, v]) => ({ k, avg: v.sum / v.n }));
      entries.sort((a, b) => a.avg - b.avg);
      const catAr: Record<string, string> = {
        letters: "الحروف",
        tashkeel: "التشكيل",
        vocabulary: "المفردات",
        spelling: "الإملاء",
        reading: "القراءة",
        listening: "الاستماع",
        speaking: "المحادثة",
        grammar: "النحو",
        expression: "التعبير",
        calligraphy: "الخط",
        culture: "الثقافة",
      };
      weakest = catAr[entries[0].k] ?? weakest;
      best = catAr[entries[entries.length - 1].k] ?? best;
    }
  } catch {
    /* ignore */
  }
  return {
    level: learner.level,
    xp: learner.xp,
    streak: learner.streak,
    minutesLearned: learner.minutesLearned,
    lessonsCompleted: learner.lessonsCompleted,
    accuracy,
    weakest,
    best,
    totalWordsLearned: learner.totalWordsLearned,
  };
}

/* Record a finished lesson — resilient: never throws to the caller */
export async function recordLessonCompletion(input: {
  learnerId: number;
  slug: string;
  accuracy: number;
  xp: number;
  coins: number;
  stars: number;
  gameType: string;
  durationSec: number;
}) {
  let lessonId = 1;
  try {
    const [lesson] = await db
      .select({ id: lessonsTable.id })
      .from(lessonsTable)
      .where(eq(lessonsTable.slug, input.slug))
      .limit(1);
    if (lesson) lessonId = lesson.id;
  } catch {
    /* ignore */
  }

  const stars = Math.max(1, Math.min(3, input.stars));

  try {
    const learner = await getLearner();
    const xpNew = learner.xp + input.xp;
    const rank = xpNew >= 2500 ? 8 : xpNew >= 1900 ? 7 : xpNew >= 1400 ? 6 : xpNew >= 1000 ? 5 : xpNew >= 700 ? 4 : xpNew >= 450 ? 3 : xpNew >= 250 ? 2 : 1;
    const minutesAdded = Math.max(1, Math.round(input.durationSec / 60));

    await db
      .update(learnerProfiles)
      .set({
        xp: xpNew,
        coins: learner.coins + input.coins,
        gems: learner.gems + (stars === 3 ? 1 : 0),
        hearts: Math.min(5, learner.hearts + (stars === 3 ? 1 : 0)),
        lessonsCompleted: sql`${learnerProfiles.lessonsCompleted} + 1`,
        totalWordsLearned: sql`${learnerProfiles.totalWordsLearned} + ${Math.round(input.accuracy / 20)}`,
        minutesLearned: sql`${learnerProfiles.minutesLearned} + ${minutesAdded}`,
        todayMinutes: sql`${learnerProfiles.todayMinutes} + ${minutesAdded}`,
        streak: sql`greatest(${learnerProfiles.streak}, ${learner.streak})`,
        rank,
      })
      .where(eq(learnerProfiles.id, input.learnerId));

    await db
      .insert(lessonProgress)
      .values({
        learnerId: input.learnerId,
        lessonId,
        completed: true,
        stars,
        accuracy: input.accuracy,
        bestAccuracy: input.accuracy,
        attempts: 1,
      })
      .onConflictDoNothing();

    await db.update(lessonProgress).set({
      completed: true,
      stars: sql`greatest(${lessonProgress.stars}, ${stars})`,
      accuracy: input.accuracy,
      bestAccuracy: sql`greatest(${lessonProgress.bestAccuracy}, ${input.accuracy})`,
      attempts: sql`${lessonProgress.attempts} + 1`,
      lastPlayedAt: new Date(),
    }).where(sql`${lessonProgress.learnerId} = ${input.learnerId} and ${lessonProgress.lessonId} = ${lessonId}`);

    await db.insert(gameSessions).values({
      learnerId: input.learnerId,
      learnerName: learner.name,
      avatar: learner.avatar,
      gameType: input.gameType as never,
      score: input.xp,
      accuracy: input.accuracy,
      xpEarned: input.xp,
      durationSec: input.durationSec,
    });

    return { ok: true as const, learner: await getLearner() };
  } catch {
    return { ok: false as const, learner: DEFAULT_LEARNER };
  }
}
