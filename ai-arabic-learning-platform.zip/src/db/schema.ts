import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  pgEnum,
  real,
  index,
} from "drizzle-orm/pg-core";

/**
 * نون (Noon) — Smart Arabic Learning Platform
 * Database schema. Modular by design so new curricula, languages,
 * games and AI content can be added without rebuilding the system.
 */

export const learnerLevel = pgEnum("learner_level", [
  "beginner",
  "elementary",
  "intermediate",
  "advanced",
]);

export const roleEnum = pgEnum("account_role", [
  "parent",
  "teacher",
  "admin",
  "center",
]);

export const lessonCategory = pgEnum("lesson_category", [
  "letters", // الحروف
  "tashkeel", // التشكيل
  "vocabulary", // المفردات
  "spelling", // الإملاء
  "reading", // القراءة
  "listening", // الاستماع
  "speaking", // المحادثة
  "grammar", // النحو
  "expression", // التعبير
  "calligraphy", // الخط العربي
  "culture", // الثقافة الإماراتية
]);

export const gameTypeEnum = pgEnum("game_type", [
  "match",
  "memory",
  "quiz",
  "wordorder",
  "listen",
  "trace",
  "spell",
  "adventure",
]);

/* ------------------------------------------------------------------ */
/* Accounts (parents / teachers / admins / centers)                    */
/* ------------------------------------------------------------------ */
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: roleEnum("role").notNull().default("parent"),
  interfaceLang: text("interface_lang").notNull().default("ar"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/* Learner profiles (children / students)                              */
/* ------------------------------------------------------------------ */
export const learnerProfiles = pgTable(
  "learner_profiles",
  {
    id: serial("id").primaryKey(),
    accountId: integer("account_id"),
    name: text("name").notNull(),
    avatar: text("avatar").notNull().default("🦊"),
    age: integer("age").notNull().default(7),
    grade: text("grade"),
    level: learnerLevel("level").notNull().default("beginner"),
    curriculum: text("curriculum").notNull().default("uae"), // uae, gcc, custom
    xp: integer("xp").notNull().default(0),
    coins: integer("coins").notNull().default(50),
    gems: integer("gems").notNull().default(0),
    hearts: integer("hearts").notNull().default(5),
    streak: integer("streak").notNull().default(0),
    rank: integer("rank").notNull().default(1),
    totalWordsLearned: integer("total_words_learned").notNull().default(0),
    lessonsCompleted: integer("lessons_completed").notNull().default(0),
    minutesLearned: integer("minutes_learned").notNull().default(0),
    dailyGoalMinutes: integer("daily_goal_minutes").notNull().default(15),
    todayMinutes: integer("today_minutes").notNull().default(0),
    interests: text("interests"),
    interfaceLang: text("interface_lang").notNull().default("ar"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("learner_account_idx").on(t.accountId)],
);

/* ------------------------------------------------------------------ */
/* Curriculum: units + lessons + embedded exercises                    */
/* ------------------------------------------------------------------ */
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  unitId: integer("unit_id").notNull(),
  unitTitle: text("unit_title").notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle"),
  category: lessonCategory("category").notNull().default("vocabulary"),
  order: integer("order").notNull().default(0),
  emoji: text("emoji").notNull().default("📚"),
  color: text("color").notNull().default("#7c3aed"),
  difficulty: integer("difficulty").notNull().default(1),
  xpReward: integer("xp_reward").notNull().default(20),
  coinReward: integer("coin_reward").notNull().default(10),
  description: text("description"),
  words: jsonb("words").$type<CurriculumWord[]>(),
  exercises: jsonb("exercises").$type<Exercise[]>(),
  curriculum: text("curriculum").notNull().default("uae"),
  isFree: boolean("is_free").notNull().default(true),
});

/* ------------------------------------------------------------------ */
/* Per-learner progress                                                */
/* ------------------------------------------------------------------ */
export const lessonProgress = pgTable(
  "lesson_progress",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull(),
    lessonId: integer("lesson_id").notNull(),
    completed: boolean("completed").notNull().default(false),
    stars: integer("stars").notNull().default(0),
    accuracy: real("accuracy").notNull().default(0),
    bestAccuracy: real("best_accuracy").notNull().default(0),
    attempts: integer("attempts").notNull().default(0),
    lastPlayedAt: timestamp("last_played_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("progress_learner_idx").on(t.learnerId)],
);

/* ------------------------------------------------------------------ */
/* Achievements / badges                                               */
/* ------------------------------------------------------------------ */
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  emoji: text("emoji").notNull().default("🏆"),
  goal: integer("goal").notNull().default(1),
  metric: text("metric").notNull().default("lessons"),
  tier: text("tier").notNull().default("bronze"),
});

export const learnerAchievements = pgTable(
  "learner_achievements",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull(),
    achievementId: integer("achievement_id").notNull(),
    earnedAt: timestamp("earned_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("la_learner_idx").on(t.learnerId)],
);

/* ------------------------------------------------------------------ */
/* AI generated content                                                */
/* ------------------------------------------------------------------ */
export const aiStories = pgTable("ai_stories", {
  id: serial("id").primaryKey(),
  learnerId: integer("learner_id").notNull(),
  title: text("title").notNull(),
  theme: text("theme").notNull(),
  level: learnerLevel("level").notNull().default("beginner"),
  paragraphs: jsonb("paragraphs").$type<string[]>(),
  vocabulary: jsonb("vocabulary").$type<CurriculumWord[]>(),
  questions: jsonb("questions").$type<StoryQuestion[]>(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const chatMessages = pgTable(
  "chat_messages",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull(),
    role: text("role").notNull(), // learner | tutor
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("chat_learner_idx").on(t.learnerId)],
);

/* ------------------------------------------------------------------ */
/* Game sessions (analytics + leaderboard)                             */
/* ------------------------------------------------------------------ */
export const gameSessions = pgTable(
  "game_sessions",
  {
    id: serial("id").primaryKey(),
    learnerId: integer("learner_id").notNull(),
    learnerName: text("learner_name").notNull(),
    avatar: text("avatar").notNull().default("🦊"),
    gameType: gameTypeEnum("game_type").notNull().default("quiz"),
    lessonTitle: text("lesson_title"),
    score: integer("score").notNull().default(0),
    accuracy: real("accuracy").notNull().default(0),
    xpEarned: integer("xp_earned").notNull().default(0),
    durationSec: integer("duration_sec").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("game_learner_idx").on(t.learnerId)],
);

/* ------------------------------------------------------------------ */
/* Shared content type definitions (mirrored in lib)                   */
/* ------------------------------------------------------------------ */
export type CurriculumWord = {
  ar: string;
  tr: string;
  en: string;
  emoji: string;
};

export type Exercise =
  | { type: "match"; prompt: string; pairs: { word: string; emoji: string }[] }
  | { type: "memory"; prompt: string; cards: { word: string; emoji: string }[] }
  | { type: "quiz"; prompt: string; question: string; options: string[]; answer: number }
  | { type: "wordorder"; prompt: string; sentence: string; translation: string }
  | { type: "listen"; prompt: string; word: string; emoji: string; options: string[] }
  | { type: "trace"; prompt: string; letter: string; name: string }
  | { type: "spell"; prompt: string; answer: string; emoji: string; hint: string };

export type StoryQuestion = {
  question: string;
  options: string[];
  answer: number;
};
