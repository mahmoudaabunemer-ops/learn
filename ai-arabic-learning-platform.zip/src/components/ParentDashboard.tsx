"use client";

import { useEffect, useState } from "react";
import type { AnalysisResult } from "@/lib/ai";
import { cn } from "@/lib/utils";

export function AnalysisCard({ learnerId }: { learnerId: number }) {
  const [data, setData] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/ai/analyze?learnerId=${learnerId}`)
      .then((r) => r.json())
      .then((d) => setData(d))
      .finally(() => setLoading(false));
  }, [learnerId]);

  if (loading) {
    return (
      <div className="card-soft space-y-3 p-6">
        <div className="h-5 w-1/3 animate-pulse rounded-full bg-brand-100" />
        <div className="h-4 w-full animate-pulse rounded-full bg-brand-100" />
        <div className="h-4 w-4/5 animate-pulse rounded-full bg-brand-100" />
      </div>
    );
  }

  if (!data) return <div className="card-soft p-6 text-ink-soft">تعذّر تحميل التحليل.</div>;

  return (
    <div className="card-soft overflow-hidden">
      <div className="flex items-center gap-2 bg-gradient-to-l from-brand-600 to-brand-400 p-4 text-white">
        <span className="text-2xl">🤖</span>
        <div>
          <h3 className="font-display font-extrabold">تحليل الذكاء الاصطناعي</h3>
          <p className="text-xs opacity-80">{data.source === "ai" ? "مولّد بنموذج لغوي حيّ" : "محرك تحليل نون"}</p>
        </div>
      </div>
      <div className="space-y-4 p-5">
        <p className="text-sm leading-relaxed text-ink">{data.summary}</p>

        <div>
          <p className="mb-2 text-sm font-bold text-mint-600">💪 نقاط القوة</p>
          <div className="flex flex-wrap gap-2">
            {data.strengths.map((s, i) => (
              <span key={i} className="chip bg-mint-50 text-mint-600">{s}</span>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 text-sm font-bold text-coral-500">🎯 مجالات تحتاج تركيزاً</p>
          <div className="space-y-2">
            {data.focus.map((f, i) => (
              <div key={i} className="rounded-2xl bg-coral-400/10 p-3">
                <div className="font-bold text-coral-600">{f.area}</div>
                <div className="text-sm text-ink-soft">{f.tip}</div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 text-sm font-bold text-brand-600">📌 خطة الأسبوع المقترحة</p>
          <ul className="space-y-1.5">
            {data.plan.map((p, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-ink">
                <span className="text-brand-500">✦</span> {p}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export function MiniBars({ data }: { data: { label: string; pct: number; color: string }[] }) {
  return (
    <div className="space-y-3">
      {data.map((d) => (
        <div key={d.label}>
          <div className="mb-1 flex justify-between text-xs font-bold text-ink-soft">
            <span>{d.label}</span>
            <span>{d.pct}%</span>
          </div>
          <div className="h-3 overflow-hidden rounded-full bg-brand-100">
            <div className={cn("h-full rounded-full")} style={{ width: `${d.pct}%`, background: d.color }} />
          </div>
        </div>
      ))}
    </div>
  );
}
