"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { levelFromXp, fmt, cn } from "@/lib/utils";
import type { Learner } from "@/lib/data";

export function TopBar({ learner }: { learner: Learner }) {
  const { level, pct } = levelFromXp(learner.xp);
  return (
    <header className="sticky top-0 z-40 glass border-b border-white/50">
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-2.5">
        <Link href="/app" className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-coral-500 font-display text-xl font-extrabold text-white">
            ن
          </span>
          <span className="hidden font-display text-lg font-extrabold text-ink sm:block">نون</span>
        </Link>

        <div className="flex items-center gap-2">
          <span className="hidden items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1.5 text-sm font-bold text-brand-700 ring-1 ring-brand-200 sm:flex">
            <span>⭐</span>
            <span>{fmt(learner.xp)}</span>
            <span className="text-xs opacity-60">XP</span>
          </span>
          <span className="flex items-center gap-1.5 rounded-full bg-sun-50 px-3 py-1.5 text-sm font-bold text-sun-600 ring-1 ring-sun-300/50">
            <span>🪙</span>
            <span>{learner.coins}</span>
          </span>
          <span className="flex items-center gap-1.5 rounded-full bg-coral-400/10 px-3 py-1.5 text-sm font-bold text-coral-600 ring-1 ring-coral-300/50">
            <span>❤️</span>
            <span>{learner.hearts}</span>
          </span>
        </div>

        <Link href="/app/profile" className="flex items-center gap-2">
          <div className="relative grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-xl ring-2 ring-brand-300">
            {learner.avatar}
          </div>
          <div className="hidden text-right leading-tight sm:block">
            <div className="text-sm font-bold text-ink">{learner.name}</div>
            <div className="text-[10px] font-semibold text-brand-600">المستوى {level} · {pct}%</div>
          </div>
        </Link>
      </div>
    </header>
  );
}

const NAV = [
  { href: "/app", icon: "🗺️", label: "تعلّم" },
  { href: "/app/tutor", icon: "🤖", label: "المعلّم" },
  { href: "/app/stories", icon: "📖", label: "القصص" },
  { href: "/app/leaderboard", icon: "🏆", label: "المتصدرون" },
  { href: "/app/shop", icon: "🛍️", label: "المتجر" },
];

export function BottomNav() {
  const path = usePathname();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-brand-100 glass pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto flex max-w-5xl items-stretch justify-around px-2">
        {NAV.map((n) => {
          const active = path === n.href;
          return (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                "flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] font-bold transition",
                active ? "text-brand-600" : "text-ink-soft/70",
              )}
            >
              <span className={cn("text-xl transition", active && "scale-110")}>{n.icon}</span>
              {n.label}
              {active && <span className="mt-0.5 h-1 w-6 rounded-full bg-brand-500" />}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
