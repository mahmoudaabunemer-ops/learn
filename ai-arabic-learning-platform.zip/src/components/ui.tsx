import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/* Decorative animated background blobs */
export function Blobs() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute -top-24 -right-24 h-80 w-80 rounded-full bg-brand-300/40 blur-3xl animate-blob" />
      <div className="absolute top-1/3 -left-24 h-72 w-72 rounded-full bg-mint-300/40 blur-3xl animate-blob" style={{ animationDelay: "-6s" }} />
      <div className="absolute bottom-0 right-1/4 h-72 w-72 rounded-full bg-sun-300/40 blur-3xl animate-blob" style={{ animationDelay: "-12s" }} />
    </div>
  );
}

/* نون the fox mascot with optional speech bubble */
export function Mascot({
  size = 64,
  bubble,
  className,
}: {
  size?: number;
  bubble?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-end gap-3", className)}>
      <div
        className="grid place-items-center rounded-3xl bg-gradient-to-br from-sun-400 to-coral-400 shadow-lg ring-4 ring-white animate-float"
        style={{ width: size, height: size, fontSize: size * 0.55 }}
      >
        🦊
      </div>
      {bubble ? (
        <div className="relative mb-1 max-w-xs rounded-2xl rounded-bl-sm bg-white px-4 py-2 text-sm font-medium text-ink shadow-md ring-1 ring-brand-100">
          {bubble}
        </div>
      ) : null}
    </div>
  );
}

/* Circular progress ring */
export function ProgressRing({
  pct,
  size = 120,
  stroke = 12,
  color = "#14b8a6",
  track = "#ece3ff",
  children,
}: {
  pct: number;
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (Math.min(100, Math.max(0, pct)) / 100) * c;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={off}
          style={{ transition: "stroke-dashoffset 0.8s cubic-bezier(0.16,1,0.3,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

export function StatChip({
  icon,
  value,
  label,
  tone = "brand",
}: {
  icon: ReactNode;
  value: ReactNode;
  label?: string;
  tone?: "brand" | "sun" | "coral" | "mint" | "sky";
}) {
  const tones: Record<string, string> = {
    brand: "bg-brand-50 text-brand-700 ring-brand-200",
    sun: "bg-sun-50 text-sun-600 ring-sun-300/60",
    coral: "bg-coral-400/10 text-coral-600 ring-coral-300/60",
    mint: "bg-mint-50 text-mint-600 ring-mint-300/60",
    sky: "bg-sky-300/10 text-sky-500 ring-sky-300/60",
  };
  return (
    <div className={cn("flex items-center gap-2 rounded-2xl px-3 py-2 ring-1", tones[tone])}>
      <span className="text-xl">{icon}</span>
      <div className="leading-tight">
        <div className="font-display text-base font-extrabold">{value}</div>
        {label ? <div className="text-[10px] font-semibold opacity-70">{label}</div> : null}
      </div>
    </div>
  );
}

export function SectionTitle({
  eyebrow,
  title,
  desc,
  center,
}: {
  eyebrow?: string;
  title: ReactNode;
  desc?: ReactNode;
  center?: boolean;
}) {
  return (
    <div className={cn("max-w-2xl", center && "mx-auto text-center")}>
      {eyebrow ? (
        <span className="chip bg-brand-100 text-brand-700">{eyebrow}</span>
      ) : null}
      <h2 className="font-display mt-3 text-3xl font-extrabold leading-tight text-ink sm:text-4xl">{title}</h2>
      {desc ? <p className="mt-3 text-base leading-relaxed text-ink-soft">{desc}</p> : null}
    </div>
  );
}

export function Stars({ count, size = 18 }: { count: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3].map((i) => (
        <span key={i} style={{ fontSize: size }} className={i <= count ? "" : "opacity-25 grayscale"}>
          ⭐
        </span>
      ))}
    </div>
  );
}
