"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

type Item = { id: string; emoji: string; name: string; price: number; cat: string };

const ITEMS: Item[] = [
  { id: "av1", emoji: "🐼", name: "الباندا", price: 50, cat: "شخصيات" },
  { id: "av2", emoji: "🦄", name: "اليونيكورن", price: 80, cat: "شخصيات" },
  { id: "av3", emoji: "🐯", name: "النمر", price: 60, cat: "شخصيات" },
  { id: "av4", emoji: "🦉", name: "البومة الحكيمة", price: 70, cat: "شخصيات" },
  { id: "pw1", emoji: "❤️", name: "تعبئة القلوب", price: 30, cat: "قوى خاصة" },
  { id: "pw2", emoji: "🛡️", name: "حماية السلسلة", price: 40, cat: "قوى خاصة" },
  { id: "pw3", emoji: "⏳", name: "وقت إضافي", price: 25, cat: "قوى خاصة" },
  { id: "pw4", emoji: "✨", name: "مضاعفة النقاط", price: 50, cat: "قوى خاصة" },
  { id: "sk1", emoji: "🌟", name: "سمة ذهبية", price: 100, cat: "سمات" },
  { id: "sk2", emoji: "🌌", name: "سمة الفضاء", price: 100, cat: "سمات" },
];

export function Shop({ coins }: { coins: number }) {
  const [balance, setBalance] = useState(coins);
  const [owned, setOwned] = useState<string[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  function buy(item: Item) {
    if (owned.includes(item.id)) {
      flash("تمتلك هذا العنصر بالفعل ✔");
      return;
    }
    if (balance < item.price) {
      flash("🪙 لا تملك عملات كافية — أكمل دروساً لكسب المزيد!");
      return;
    }
    setBalance((b) => b - item.price);
    setOwned((o) => [...o, item.id]);
    flash(`🎉 تم شراء «${item.name}»!`);
  }

  function flash(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  }

  const cats = ["شخصيات", "قوى خاصة", "سمات"];

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">🛍️ متجر المكافآت</h1>
          <p className="text-sm text-ink-soft">اشترِ شخصيات وقوى خاصة برصيدك</p>
        </div>
        <div className="flex items-center gap-2 rounded-full bg-sun-50 px-4 py-2 font-display font-extrabold text-sun-600 ring-1 ring-sun-300/50">
          🪙 {balance}
        </div>
      </div>

      {cats.map((cat) => (
        <section key={cat} className="mb-6">
          <h2 className="mb-3 font-display font-bold text-ink">{cat}</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {ITEMS.filter((i) => i.cat === cat).map((item) => {
              const isOwned = owned.includes(item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => buy(item)}
                  className={cn(
                    "card-soft flex flex-col items-center gap-1 p-4 transition hover:-translate-y-1",
                    isOwned && "ring-2 ring-mint-400",
                  )}
                >
                  <span className="text-4xl">{item.emoji}</span>
                  <span className="text-sm font-bold text-ink">{item.name}</span>
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-xs font-bold",
                      isOwned ? "bg-mint-100 text-mint-600" : "bg-sun-50 text-sun-600",
                    )}
                  >
                    {isOwned ? "✔ مملوك" : `🪙 ${item.price}`}
                  </span>
                </button>
              );
            })}
          </div>
        </section>
      ))}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 mx-auto w-fit animate-rise rounded-full bg-ink px-5 py-3 text-sm font-bold text-white shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
