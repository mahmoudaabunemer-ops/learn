"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LANGUAGES, makeT, dirOf, type Lang } from "@/lib/i18n";
import { ProgressRing, Mascot } from "@/components/ui";
import { levelFromXp, fmt } from "@/lib/utils";

/* Shared language state (persisted, flips document direction) */
function readLang(): Lang {
  if (typeof window === "undefined") return "ar";
  return (localStorage.getItem("noon-lang") as Lang) || "ar";
}

export function useLang() {
  const [lang, setLangState] = useState<Lang>("ar");
  useEffect(() => {
    const l = readLang();
    setLangState(l);
    document.documentElement.lang = l;
    document.documentElement.dir = dirOf(l);
  }, []);
  const setLang = (l: Lang) => {
    if (typeof window !== "undefined") localStorage.setItem("noon-lang", l);
    document.documentElement.lang = l;
    document.documentElement.dir = dirOf(l);
    setLangState(l);
  };
  return { lang, setLang, t: makeT(lang) };
}

export function LangSwitch() {
  const { lang, setLang } = useLang();
  return (
    <div className="relative">
      <select
        value={lang}
        onChange={(e) => setLang(e.target.value as Lang)}
        className="cursor-pointer rounded-full border-2 border-brand-200 bg-white px-3 py-2 text-sm font-bold text-brand-700 outline-none transition hover:border-brand-400"
        aria-label="Language"
      >
        {LANGUAGES.map((l) => (
          <option key={l.code} value={l.code}>
            {l.flag} {l.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export function SiteNav() {
  const { t } = useLang();
  const links = [
    { href: "#features", label: "المميزات" },
    { href: "#ai", label: "الذكاء الاصطناعي" },
    { href: "#games", label: "الألعاب" },
    { href: "#pricing", label: "الأسعار" },
    { href: "#roadmap", label: "خارطة الطريق" },
  ];
  return (
    <header className="sticky top-0 z-40 glass border-b border-white/40">
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-coral-500 font-display text-2xl font-extrabold text-white shadow">
            ن
          </span>
          <span className="font-display text-xl font-extrabold text-ink">نون</span>
        </Link>
        <div className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-full px-3 py-2 text-sm font-bold text-ink-soft transition hover:bg-brand-50 hover:text-brand-700"
            >
              {l.label}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <LangSwitch />
          <Link href="/app" className="btn-primary !px-4 !py-2 text-sm">
            {t("hero.cta")}
          </Link>
        </div>
      </nav>
    </header>
  );
}

export function Hero() {
  const { t } = useLang();
  return (
    <section className="relative overflow-hidden bg-grid">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
        <div className="animate-rise">
          <span className="chip bg-white/80 text-brand-700 ring-1 ring-brand-200 backdrop-blur">
            ✨ {t("hero.badge")}
          </span>
          <h1 className="font-display mt-5 text-4xl font-extrabold leading-[1.1] text-ink sm:text-5xl lg:text-6xl">
            <span className="text-gradient">{t("hero.title")}</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-soft">{t("hero.subtitle")}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/app" className="btn-primary text-lg">
              🚀 {t("hero.cta")}
            </Link>
            <Link href="/parent" className="btn-ghost text-lg">
              👨‍👩‍👧 {t("hero.cta2")}
            </Link>
          </div>
          <div className="mt-10 flex flex-wrap gap-6">
            {[
              { n: "٥٠٠ ألف+", l: t("hero.stat1") },
              { n: "+٣٠٠", l: t("hero.stat2") },
              { n: "٩٦٪", l: t("hero.stat3") },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-3xl font-extrabold text-brand-600">{s.n}</div>
                <div className="text-sm font-semibold text-ink-soft">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Visual cluster */}
        <div className="relative mx-auto flex h-[420px] w-full max-w-md items-center justify-center">
          <div className="absolute h-72 w-72 rounded-full bg-gradient-to-br from-brand-400 via-coral-400 to-sun-400 opacity-30 blur-2xl" />
          <div className="relative grid h-72 w-72 place-items-center rounded-[42%] bg-white shadow-2xl ring-8 ring-white animate-blob">
            <ProgressRing pct={72} size={220} stroke={16} color="#7c3aed">
              <div className="text-center">
                <div className="text-6xl">🦊</div>
                <div className="font-display mt-1 text-sm font-bold text-brand-700">المستوى ٣</div>
              </div>
            </ProgressRing>
          </div>
          {/* floating game cards */}
          {[
            { e: "🎯", t: "مطابقة", c: "from-brand-500 to-brand-700", p: "top-2 right-0", d: "0s" },
            { e: "🧩", t: "ترتيب", c: "from-sun-400 to-sun-600", p: "bottom-6 right-2", d: "-2s" },
            { e: "🔊", t: "استماع", c: "from-mint-400 to-mint-600", p: "top-10 left-0", d: "-4s" },
            { e: "🏆", t: "+٥٠ نقطة", c: "from-coral-400 to-coral-600", p: "bottom-0 left-4", d: "-1s" },
          ].map((f) => (
            <div
              key={f.t}
              className={`absolute ${f.p} flex items-center gap-2 rounded-2xl bg-gradient-to-br ${f.c} px-3 py-2 text-sm font-bold text-white shadow-xl animate-float`}
              style={{ animationDelay: f.d }}
            >
              <span className="text-xl">{f.e}</span>
              {f.t}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="mt-20 border-t border-brand-100 bg-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-coral-500 font-display text-2xl font-extrabold text-white">
              ن
            </span>
            <span className="font-display text-xl font-extrabold text-ink">نون</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-ink-soft">
            عالم العربية الذكي — نُعلّم الأجيال لغة القرآن والهوية الإماراتية بالذكاء الاصطناعي والألعاب.
          </p>
        </div>
        {[
          { h: "المنصة", items: ["للأطفال", "للمقيمين", "للمدارس", "للمعلمين"] },
          { h: "المنتج", items: ["المعلم الذكي", "مولد القصص", "الألعاب", "المتجر"] },
          { h: "الشركة", items: ["من نحن", "خارطة الطريق", "الأسعار", "تواصل معنا"] },
        ].map((col) => (
          <div key={col.h}>
            <h4 className="font-display font-bold text-ink">{col.h}</h4>
            <ul className="mt-3 space-y-2 text-sm text-ink-soft">
              {col.items.map((i) => (
                <li key={i} className="cursor-pointer transition hover:text-brand-600">
                  {i}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-brand-100 py-5 text-center text-sm text-ink-soft">
        © ٢٠٢٦ نون · صُمّم بكل ❤️ في الإمارات · متوافق مع COPPA وGDPR
      </div>
    </footer>
  );
}
