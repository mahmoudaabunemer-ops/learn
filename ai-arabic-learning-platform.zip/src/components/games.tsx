"use client";

import { useEffect, useRef, useState } from "react";
import type { Exercise } from "@/db/schema";
import { shuffle, cn } from "@/lib/utils";

/* Browser text-to-speech for Arabic pronunciation / listening games */
export function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ar-SA";
    u.rate = 0.78;
    u.pitch = 1.05;
    window.speechSynthesis.speak(u);
  } catch {
    /* noop */
  }
}

export function Speaker({ text, className }: { text: string; className?: string }) {
  return (
    <button
      type="button"
      onClick={() => speak(text)}
      className={cn(
        "grid place-items-center rounded-full bg-brand-500 text-white shadow-md transition hover:scale-110 active:scale-95",
        className,
      )}
      aria-label="استمع"
    >
      🔊
    </button>
  );
}

/* ================================================================== */
/* Individual mini-games                                               */
/* ================================================================== */

function MatchGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "match" }>; onAnswer: (ok: boolean) => void }) {
  const pairs = ex.pairs.map((p, i) => ({ ...p, id: i }));
  const emojis = useRef(shuffle(pairs)).current;
  const words = useRef(shuffle(pairs)).current;
  const [matched, setMatched] = useState<number[]>([]);
  const [selEmoji, setSelEmoji] = useState<number | null>(null);
  const [wrong, setWrong] = useState<number | null>(null);

  useEffect(() => {
    if (matched.length && matched.length === pairs.length) onAnswer(true);
  }, [matched, pairs.length, onAnswer]);

  function pickWord(id: number) {
    if (selEmoji === null || matched.includes(id)) return;
    if (selEmoji === id) {
      setMatched((m) => [...m, id]);
      setSelEmoji(null);
    } else {
      setWrong(id);
      setTimeout(() => setWrong(null), 500);
    }
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-5">
      <div className="grid gap-3">
        {emojis.map((p) => {
          const done = matched.includes(p.id);
          const active = selEmoji === p.id;
          return (
            <button
              key={`e${p.id}`}
              onClick={() => !done && setSelEmoji(p.id)}
              className={cn(
                "card-soft grid h-20 place-items-center text-4xl transition",
                done && "opacity-40",
                active && "ring-4 ring-brand-400 scale-[1.03]",
              )}
            >
              {p.emoji}
            </button>
          );
        })}
      </div>
      <div className="grid gap-3">
        {words.map((p) => {
          const done = matched.includes(p.id);
          const bad = wrong === p.id;
          return (
            <button
              key={`w${p.id}`}
              onClick={() => pickWord(p.id)}
              className={cn(
                "card-soft grid h-20 place-items-center px-2 text-center font-display text-xl font-bold transition",
                done && "bg-mint-50 text-mint-600 opacity-50",
                bad && "ring-4 ring-coral-400 animate-wiggle",
              )}
            >
              {p.word}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function MemoryGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "memory" }>; onAnswer: (ok: boolean) => void }) {
  const pairs = ex.cards.map((c, i) => ({ ...c, id: i }));
  const deck = useRef(
    shuffle([
      ...pairs.map((p) => ({ ...p, face: "emoji" as const, uid: `${p.id}-e` })),
      ...pairs.map((p) => ({ ...p, face: "word" as const, uid: `${p.id}-w` })),
    ]),
  ).current;
  const [flipped, setFlipped] = useState<string[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [lock, setLock] = useState(false);

  useEffect(() => {
    if (matched.length === pairs.length) onAnswer(true);
  }, [matched, pairs.length, onAnswer]);

  function flip(uid: string, id: number) {
    if (lock || flipped.includes(uid) || matched.includes(id)) return;
    const next = [...flipped, uid];
    setFlipped(next);
    if (next.length === 2) {
      setLock(true);
      const [a, b] = next;
      const idA = deck.find((d) => d.uid === a)!.id;
      const idB = deck.find((d) => d.uid === b)!.id;
      if (idA === idB && a !== b) {
        setTimeout(() => {
          setMatched((m) => [...m, idA]);
          setFlipped([]);
          setLock(false);
        }, 500);
      } else {
        setTimeout(() => {
          setFlipped([]);
          setLock(false);
        }, 900);
      }
    }
  }

  return (
    <div className="grid grid-cols-4 gap-2 sm:gap-3">
      {deck.map((card) => {
        const show = flipped.includes(card.uid) || matched.includes(card.id);
        const done = matched.includes(card.id);
        return (
          <button
            key={card.uid}
            onClick={() => flip(card.uid, card.id)}
            className={cn(
              "relative grid aspect-square place-items-center rounded-2xl text-2xl font-bold transition duration-300",
              show ? "bg-white shadow-md ring-1 ring-brand-100" : "bg-gradient-to-br from-brand-400 to-brand-600 text-white",
              done && "opacity-50",
            )}
            style={{ transform: show ? "rotateY(0deg)" : undefined }}
          >
            {show ? (card.face === "emoji" ? card.emoji : card.word) : "؟"}
          </button>
        );
      })}
    </div>
  );
}

function QuizGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "quiz" }>; onAnswer: (ok: boolean) => void }) {
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div>
      <div className="mb-4 rounded-3xl bg-brand-50 p-4 text-center font-display text-lg font-bold text-brand-700">
        {ex.question}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {ex.options.map((opt, i) => {
          const isAns = i === ex.answer;
          const state =
            picked === null ? "idle" : isAns ? "right" : picked === i ? "wrong" : "dim";
          return (
            <button
              key={i}
              disabled={picked !== null}
              onClick={() => {
                setPicked(i);
                onAnswer(i === ex.answer);
              }}
              className={cn(
                "card-soft px-4 py-4 text-lg font-bold transition",
                state === "idle" && "hover:-translate-y-0.5 hover:ring-2 hover:ring-brand-200",
                state === "right" && "bg-mint-50 text-mint-600 ring-2 ring-mint-400",
                state === "wrong" && "bg-coral-400/10 text-coral-600 ring-2 ring-coral-400 animate-wiggle",
                state === "dim" && "opacity-40",
              )}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function WordOrderGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "wordorder" }>; onAnswer: (ok: boolean) => void }) {
  const target = ex.sentence.split(" ");
  const [pool, setPool] = useState(() => shuffle(target.map((w, i) => ({ w, id: i }))));
  const [built, setBuilt] = useState<{ w: string; id: number }[]>([]);

  function add(item: { w: string; id: number }) {
    setPool((p) => p.filter((x) => x.id !== item.id));
    setBuilt((b) => [...b, item]);
  }
  function remove(item: { w: string; id: number }) {
    setBuilt((b) => b.filter((x) => x.id !== item.id));
    setPool((p) => [...p, item]);
  }
  function check() {
    onAnswer(built.map((b) => b.w).join(" ") === ex.sentence);
  }

  return (
    <div>
      <p className="mb-3 text-center text-sm font-semibold text-ink-soft">💡 {ex.translation}</p>
      <div className="mb-4 flex min-h-[72px] flex-wrap items-center gap-2 rounded-2xl border-2 border-dashed border-brand-200 bg-white/60 p-3">
        {built.length === 0 && <span className="text-sm text-ink-soft/60">اضغط الكلمات بالترتيب الصحيح…</span>}
        {built.map((b) => (
          <button key={b.id} onClick={() => remove(b)} className="rounded-xl bg-brand-500 px-3 py-2 font-display font-bold text-white shadow">
            {b.w}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {pool.map((p) => (
          <button key={p.id} onClick={() => add(p)} className="card-soft px-4 py-3 font-display font-bold transition hover:-translate-y-0.5">
            {p.w}
          </button>
        ))}
      </div>
      <div className="mt-5 text-center">
        <button onClick={check} disabled={pool.length !== 0} className={cn("btn-primary", pool.length !== 0 && "opacity-40")}>
          تحقّق ✓
        </button>
      </div>
    </div>
  );
}

function ListenGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "listen" }>; onAnswer: (ok: boolean) => void }) {
  const [picked, setPicked] = useState<number | null>(null);
  useEffect(() => {
    const t = setTimeout(() => speak(ex.word), 350);
    return () => clearTimeout(t);
  }, [ex.word]);
  return (
    <div className="text-center">
      <button onClick={() => speak(ex.word)} className="mx-auto mb-5 grid h-24 w-24 place-items-center rounded-full bg-gradient-to-br from-sky-400 to-brand-500 text-4xl text-white shadow-xl transition hover:scale-105 active:scale-95 animate-float">
        🔊
      </button>
      <p className="mb-4 text-sm font-semibold text-ink-soft">استمع جيداً ثم اختر الكلمة الصحيحة</p>
      <div className="grid grid-cols-2 gap-3">
        {ex.options.map((opt, i) => {
          const isAns = opt === ex.word;
          const state = picked === null ? "idle" : isAns ? "right" : picked === i ? "wrong" : "dim";
          return (
            <button
              key={i}
              disabled={picked !== null}
              onClick={() => {
                setPicked(i);
                onAnswer(opt === ex.word);
              }}
              className={cn(
                "card-soft px-4 py-4 font-display text-lg font-bold transition",
                state === "idle" && "hover:-translate-y-0.5",
                state === "right" && "bg-mint-50 text-mint-600 ring-2 ring-mint-400",
                state === "wrong" && "bg-coral-400/10 text-coral-600 ring-2 ring-coral-400",
                state === "dim" && "opacity-40",
              )}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function TraceGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "trace" }>; onAnswer: (ok: boolean) => void }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawing = useRef(false);
  const drew = useRef(false);
  const [done, setDone] = useState(false);

  function pos(e: React.PointerEvent) {
    const c = canvasRef.current!;
    const rect = c.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }
  function down(e: React.PointerEvent) {
    drawing.current = true;
    const ctx = canvasRef.current!.getContext("2d")!;
    const { x, y } = pos(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
  }
  function move(e: React.PointerEvent) {
    if (!drawing.current) return;
    drew.current = true;
    const ctx = canvasRef.current!.getContext("2d")!;
    const { x, y } = pos(e);
    ctx.lineWidth = 16;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#7c3aed";
    ctx.lineTo(x, y);
    ctx.stroke();
  }
  function up() {
    drawing.current = false;
  }

  return (
    <div className="text-center">
      <p className="mb-1 font-display text-xl font-bold text-brand-700">تتبّع حرف {ex.name}</p>
      <p className="mb-3 text-sm text-ink-soft">ارسم فوق الحرف بإصبعك</p>
      <div className="relative mx-auto" style={{ width: 240, height: 240 }}>
        <div className="absolute inset-0 grid place-items-center font-display text-[160px] leading-none text-brand-200">
          {ex.letter}
        </div>
        <canvas
          ref={canvasRef}
          width={240}
          height={240}
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerLeave={up}
          className="absolute inset-0 touch-none rounded-3xl"
        />
      </div>
      <button
        onClick={() => {
          setDone(true);
          onAnswer(true);
        }}
        disabled={done}
        className="btn-primary mt-4"
      >
        تأكّدت ✓
      </button>
    </div>
  );
}

function SpellGame({ ex, onAnswer }: { ex: Extract<Exercise, { type: "spell" }>; onAnswer: (ok: boolean) => void }) {
  const letters = ex.answer.split("");
  const distractors = ["م", "ل", "ن", "ر", "ت", "ب", "س"].filter((d) => !letters.includes(d)).slice(0, 3);
  const tiles = useRef(shuffle([...letters, ...distractors])).current;
  const [pool, setPool] = useState(tiles);
  const [built, setBuilt] = useState<string[]>([]);
  const [checked, setChecked] = useState(false);

  const ok = built.join("") === ex.answer;

  return (
    <div className="text-center">
      <div className="mb-1 text-6xl">{ex.emoji}</div>
      <p className="mb-4 text-sm font-semibold text-ink-soft">رتب الحروف لتكتب: {ex.hint}</p>
      <div className="mb-4 flex min-h-[64px] flex-wrap items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-brand-200 bg-white/60 p-3">
        {built.length === 0 && <span className="text-sm text-ink-soft/60">المكان هنا…</span>}
        {built.map((l, i) => (
          <button
            key={i}
            onClick={() => {
              setBuilt((b) => b.filter((_, j) => j !== i));
              setPool((p) => [...p, l]);
              setChecked(false);
            }}
            className={cn(
              "grid h-12 w-10 place-items-center rounded-xl font-display text-2xl font-bold shadow",
              checked ? (ok ? "bg-mint-50 text-mint-600" : "bg-coral-400/10 text-coral-600") : "bg-brand-500 text-white",
            )}
          >
            {l}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {pool.map((l, i) => (
          <button
            key={i}
            onClick={() => {
              setBuilt((b) => [...b, l]);
              setPool((p) => p.filter((_, j) => j !== i));
              setChecked(false);
            }}
            className="card-soft grid h-12 w-10 place-items-center font-display text-2xl font-bold transition hover:-translate-y-0.5"
          >
            {l}
          </button>
        ))}
      </div>
      <div className="mt-5">
        <button
          onClick={() => {
            setChecked(true);
            onAnswer(ok);
          }}
          disabled={built.length !== letters.length}
          className={cn("btn-primary", built.length !== letters.length && "opacity-40")}
        >
          تحقّق ✓
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
/* Engine — sequences exercises, tracks score, calls onComplete        */
/* ================================================================== */

export type GameResult = { accuracy: number; stars: number; xp: number; coins: number; durationSec: number };

export function GameEngine({
  exercises,
  xpReward,
  coinReward,
  onComplete,
}: {
  exercises: Exercise[];
  xpReward: number;
  coinReward: number;
  onComplete: (r: GameResult) => void;
}) {
  const [idx, setIdx] = useState(0);
  const [feedback, setFeedback] = useState<null | boolean>(null);
  const [correct, setCorrect] = useState(0);
  const start = useRef(Date.now());
  const total = exercises.length;
  const ex = exercises[Math.min(idx, total - 1)];
  const answeredRef = useRef(0);

  function handleAnswer(ok: boolean) {
    if (feedback !== null) return;
    setFeedback(ok);
    answeredRef.current += 1;
    if (ok) setCorrect((c) => c + 1);
    if (ok) speak("أحسنت");
  }

  function finish() {
    const accuracy = Math.round((correct / total) * 100);
    const stars = accuracy >= 90 ? 3 : accuracy >= 70 ? 2 : 1;
    onComplete({
      accuracy,
      stars,
      xp: Math.max(5, Math.round(xpReward * (0.5 + accuracy / 200))),
      coins: Math.round(coinReward * (accuracy / 100)),
      durationSec: Math.round((Date.now() - start.current) / 1000),
    });
  }

  function next() {
    if (idx + 1 >= total) {
      finish();
    } else {
      setIdx((i) => i + 1);
      setFeedback(null);
    }
  }

  return (
    <div>
      {/* progress */}
      <div className="mb-5 flex items-center gap-3">
        <div className="h-3 flex-1 overflow-hidden rounded-full bg-brand-100">
          <div
            className="h-full rounded-full bg-gradient-to-l from-brand-500 to-mint-400 transition-all duration-500"
            style={{ width: `${((idx + (feedback !== null ? 1 : 0)) / total) * 100}%` }}
          />
        </div>
        <span className="font-display text-sm font-bold text-brand-700">
          {idx + 1}/{total}
        </span>
      </div>

      {/* exercise prompt */}
      <p className="mb-5 text-center font-display text-lg font-extrabold text-ink">{ex.prompt}</p>

      {/* exercise body */}
      <div className="min-h-[280px]">
        {ex.type === "match" && <MatchGame ex={ex} onAnswer={handleAnswer} />}
        {ex.type === "memory" && <MemoryGame ex={ex} onAnswer={handleAnswer} />}
        {ex.type === "quiz" && <QuizGame ex={ex} onAnswer={handleAnswer} />}
        {ex.type === "wordorder" && <WordOrderGame ex={ex} onAnswer={handleAnswer} />}
        {ex.type === "listen" && <ListenGame ex={ex} onAnswer={handleAnswer} />}
        {ex.type === "trace" && <TraceGame ex={ex} onAnswer={handleAnswer} />}
        {ex.type === "spell" && <SpellGame ex={ex} onAnswer={handleAnswer} />}
      </div>

      {/* feedback overlay */}
      {feedback !== null && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-ink/40 backdrop-blur-sm p-6 animate-rise">
          <div className="card-soft w-full max-w-sm p-8 text-center">
            <div className="text-7xl animate-pop">{feedback ? "🎉" : "💪"}</div>
            <h3 className={cn("font-display mt-3 text-2xl font-extrabold", feedback ? "text-mint-600" : "text-coral-500")}>
              {feedback ? "أحسنت! إجابة صحيحة" : "لا بأس، حاول مرة أخرى"}
            </h3>
            <p className="mt-2 text-sm text-ink-soft">
              {feedback ? "استمر، أنت بطل العربية!" : "التعلّم يحتاج صبراً، ستنجح في المرة القادمة!"}
            </p>
            <button onClick={next} className="btn-primary mt-6 w-full">
              {idx + 1 >= total ? "إنهاء الدرس 🏁" : "التالي ←"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
