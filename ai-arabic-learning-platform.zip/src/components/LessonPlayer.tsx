"use client";

import { useState } from "react";
import Link from "next/link";
import { GameEngine, type GameResult, speak } from "@/components/games";
import type { Exercise } from "@/db/schema";
import { cn } from "@/lib/utils";

export function LessonPlayer({
  slug,
  title,
  emoji,
  color,
  exercises,
  xpReward,
  coinReward,
  learnerId,
}: {
  slug: string;
  title: string;
  emoji: string;
  color: string;
  exercises: Exercise[];
  xpReward: number;
  coinReward: number;
  learnerId: number;
}) {
  const [phase, setPhase] = useState<"play" | "done">("play");
  const [result, setResult] = useState<GameResult | null>(null);

  function handleComplete(r: GameResult) {
    setResult(r);
    setPhase("done");
    speak("رائع! لقد أنهيت الدرس");
    fetch("/api/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        learnerId,
        slug,
        accuracy: r.accuracy,
        xp: r.xp,
        coins: r.coins,
        stars: r.stars,
        gameType: "quiz",
        durationSec: r.durationSec,
      }),
    }).catch(() => {});
  }

  if (phase === "done" && result) {
    return (
      <div className="mx-auto max-w-md py-6 text-center">
        <div className="animate-pop text-8xl">🏆</div>
        <h1 className="font-display mt-3 text-3xl font-extrabold text-gradient">أحسنت يا بطل!</h1>
        <p className="mt-2 text-ink-soft">أنهيت درس «{title}»</p>

        <div className="my-6 flex justify-center gap-3">
          {[1, 2, 3].map((i) => (
            <span
              key={i}
              className={cn("text-6xl transition", i <= result.stars ? "animate-pop" : "opacity-20 grayscale")}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              ⭐
            </span>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Reward icon="⚡" value={`+${result.xp}`} label="نقاط خبرة" tone="brand" />
          <Reward icon="🪙" value={`+${result.coins}`} label="عملات" tone="sun" />
          <Reward icon="🎯" value={`${result.accuracy}%`} label="دقة" tone="mint" />
        </div>

        <div className="mt-8 flex flex-col gap-3">
          <Link href="/app" className="btn-primary w-full">
            العودة إلى المسار 🗺️
          </Link>
          <button
            onClick={() => {
              setResult(null);
              setPhase("play");
            }}
            className="btn-ghost w-full"
          >
            🔁 إعادة الدرس
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-5 flex items-center justify-between">
        <Link href="/app" className="grid h-10 w-10 place-items-center rounded-full bg-white text-xl shadow ring-1 ring-brand-100">
          ✕
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-2xl">{emoji}</span>
          <h1 className="font-display text-lg font-extrabold text-ink">{title}</h1>
        </div>
        <div className="w-10" />
      </div>

      <div className="card-soft p-5 sm:p-7">
        <GameEngine
          key={phase}
          exercises={exercises}
          xpReward={xpReward}
          coinReward={coinReward}
          onComplete={handleComplete}
        />
      </div>
    </div>
  );
}

function Reward({ icon, value, label, tone }: { icon: string; value: string; label: string; tone: string }) {
  const tones: Record<string, string> = {
    brand: "bg-brand-50 text-brand-700",
    sun: "bg-sun-50 text-sun-600",
    mint: "bg-mint-50 text-mint-600",
  };
  return (
    <div className={cn("rounded-2xl p-4", tones[tone])}>
      <div className="text-3xl">{icon}</div>
      <div className="font-display mt-1 text-xl font-extrabold">{value}</div>
      <div className="text-[11px] font-semibold opacity-70">{label}</div>
    </div>
  );
}
