import Link from "next/link";
import { SiteNav, Hero, Footer } from "@/components/site";
import { SectionTitle, Mascot } from "@/components/ui";
import { LANGUAGES } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export default function Landing() {
  return (
    <>
      <SiteNav />
      <Hero />

      {/* Languages + curriculum strip */}
      <section className="border-y border-brand-100 bg-white py-6">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-6 gap-y-3 px-4">
          <span className="text-sm font-bold text-ink-soft">🌍 يدعم ٨ لغات للواجهة:</span>
          {LANGUAGES.map((l) => (
            <span key={l.code} className="flex items-center gap-1 text-sm font-semibold text-ink">
              <span className="text-lg">{l.flag}</span> {l.label}
            </span>
          ))}
          <span className="chip bg-mint-50 text-mint-600">🇦🇪 متوافق مع المنهج الإماراتي</span>
        </div>
      </section>

      {/* Problem -> Solution */}
      <Section id="problem" eyebrow="المشكلة والحل" title="نحلّ تحديات تعلّم العربية من الجذور">
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          <div className="card-soft p-6">
            <h3 className="font-display text-lg font-bold text-coral-500">⚠️ التحديات</h3>
            <ul className="mt-3 space-y-2 text-sm text-ink-soft">
              {["ضعف القراءة والكتابة والإملاء", "ضعف المفردات والنحو", "صعوبة العربية للمقيمين", "اعتماد الأطفال على الإنجليزية", "قلّة المحتوى العربي التفاعلي", "طرق التدريس التقليدية"].map((p) => (
                <li key={p} className="flex items-center gap-2"><span className="text-coral-400">✕</span> {p}</li>
              ))}
            </ul>
          </div>
          <div className="card-soft border-2 border-mint-300 bg-mint-50/40 p-6">
            <h3 className="font-display text-lg font-bold text-mint-600">✅ حلّ نون</h3>
            <ul className="mt-3 space-y-2 text-sm text-ink">
              {["تعلّم تكيّفي بالذكاء الاصطناعي", "ألعاب وقصص مولّدة تلقائياً", "تصحيح النطق بالتعرف على الصوت", "خطة تعليمية شخصية لكل طفل", "محتوى ثري ومتجدّد سنوياً", "تجربة ممتعة تجمع اللعب والتعلّم"].map((p) => (
                <li key={p} className="flex items-center gap-2"><span className="text-mint-500">✓</span> {p}</li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* Features */}
      <Section id="features" eyebrow="المميزات" title="منصّة تعليمية متكاملة بالذكاء الاصطناعي" desc="كل ما يحتاجه الطفل لإتقان العربية في مكان واحد، بأسلوب ممتع وتكيّفي.">
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.t} className="card-soft group p-6 transition hover:-translate-y-1 hover:shadow-xl">
              <div className={cn("grid h-14 w-14 place-items-center rounded-2xl text-3xl", f.bg)}>{f.icon}</div>
              <h3 className="font-display mt-4 text-lg font-extrabold text-ink">{f.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-soft">{f.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* AI */}
      <Section id="ai" eyebrow="الذكاء الاصطناعي" title="وكلاء أذكياء يتعلّمون مع طفلك" desc="نظام ذكاء اصطناعي شامل يولّد المحتوى، يُدرّس، يصحّح، ويبني خطة شخصية لكل متعلّم.">
        <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <div className="card-soft relative overflow-hidden p-8">
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand-300/30 blur-2xl" />
            <Mascot size={80} bubble="أنا أتكيّف مع كل طفل! 🧠" />
            <div className="mt-6 space-y-3">
              {["Gemini · GPT-4o · Claude", "Whisper للتعرف على الصوت", "نماذج TTS عربية", "Vision لتحليل الكتابة", "Vector DB للمعرفة"].map((m) => (
                <div key={m} className="flex items-center gap-2 rounded-xl bg-brand-50 px-3 py-2 text-sm font-semibold text-brand-700">
                  <span>⚡</span> {m}
                </div>
              ))}
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {AI_AGENTS.map((a) => (
              <div key={a.t} className="card-soft p-5">
                <div className="text-3xl">{a.icon}</div>
                <h3 className="font-display mt-2 font-bold text-ink">{a.t}</h3>
                <p className="mt-1 text-sm text-ink-soft">{a.d}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* Games */}
      <Section id="games" eyebrow="الألعاب" title="أكثر من ٣٠٠ لعبة تعليمية" desc="عوالم تفاعلية تجعل التعلّم مغامرة: من الحروف إلى مدن وفضاءات كاملة.">
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {GAMES.map((g) => (
            <div key={g.t} className={cn("rounded-3xl bg-gradient-to-br p-5 text-white shadow-lg transition hover:-translate-y-1", g.c)}>
              <div className="text-4xl">{g.icon}</div>
              <h3 className="font-display mt-3 font-bold">{g.t}</h3>
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {["مطابقة", "ذاكرة", "ترتيب الكلمات", "بحث عن الكلمات", "كلمات متقاطعة", "Escape Room", "RPG تعليمية", "Trivia", "مسابقات مباشرة", "مغامرات", "سباقات", "ألغاز"].map((t) => (
            <span key={t} className="chip bg-white text-brand-700 ring-1 ring-brand-100">{t}</span>
          ))}
        </div>
      </Section>

      {/* Gamification */}
      <section className="bg-gradient-to-l from-brand-700 to-brand-500 py-16 text-white">
        <div className="mx-auto max-w-7xl px-4">
          <div className="max-w-2xl">
            <span className="chip bg-white/20 text-white">نظام التحفيز</span>
            <h2 className="font-display mt-3 text-3xl font-extrabold sm:text-4xl">التعلّم يصبح إدماناً صحياً 🎮</h2>
            <p className="mt-3 text-white/80">نحفّز الأطفال بنظام مكافآت متكامل يبني عادة التعلّم اليومية.</p>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {REWARDS.map((r) => (
              <div key={r.t} className="rounded-3xl bg-white/10 p-5 backdrop-blur">
                <div className="text-4xl">{r.icon}</div>
                <h3 className="font-display mt-2 font-bold">{r.t}</h3>
                <p className="text-sm text-white/70">{r.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Audience */}
      <Section eyebrow="لمن نحن؟" title="منصّة للجميع" desc="من الطفل في الثالثة إلى المُقيم والمدرسة ومركز تعليم العربية.">
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          {AUDIENCE.map((a) => (
            <span key={a} className="chip bg-white text-ink ring-1 ring-brand-100 shadow-sm">{a}</span>
          ))}
        </div>
        <div className="mt-8 grid gap-5 md:grid-cols-2">
          <Link href="/parent" className="card-soft group flex items-center gap-4 p-6 transition hover:-translate-y-1">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-coral-400/10 text-4xl">👨‍👩‍👧</span>
            <div>
              <h3 className="font-display text-lg font-bold text-ink">لوحة أولياء الأمور</h3>
              <p className="text-sm text-ink-soft">تقارير، توصيات AI، ساعات التعلّم ونقاط الضعف.</p>
              <span className="mt-1 inline-block text-sm font-bold text-brand-600">عرض تجريبي ←</span>
            </div>
          </Link>
          <Link href="/teacher" className="card-soft group flex items-center gap-4 p-6 transition hover:-translate-y-1">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-50 text-4xl">🏫</span>
            <div>
              <h3 className="font-display text-lg font-bold text-ink">لوحة المدارس والمعلمين</h3>
              <p className="text-sm text-ink-soft">إدارة فصول، واجبات، اختبارات وتحليل أداء.</p>
              <span className="mt-1 inline-block text-sm font-bold text-brand-600">عرض تجريبي ←</span>
            </div>
          </Link>
        </div>
      </Section>

      {/* Security + Analytics */}
      <Section eyebrow="الأمان والتحليلات" title="بيانات آمنة، ورؤى ذكية">
        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <div className="card-soft p-6">
            <h3 className="font-display text-lg font-bold text-ink">🛡️ أمان وحماية للأطفال</h3>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {["COPPA", "GDPR", "تشفير البيانات", "موافقة الوالدين", "مصادقة MFA", "صلاحيات RBAC", "سجلات تدقيق", "حماية الخصوصية"].map((s) => (
                <div key={s} className="flex items-center gap-2 rounded-xl bg-mint-50 px-3 py-2 text-sm font-bold text-mint-600">
                  <span>✓</span> {s}
                </div>
              ))}
            </div>
          </div>
          <div className="card-soft p-6">
            <h3 className="font-display text-lg font-bold text-ink">📊 لوحة تحليلات احترافية</h3>
            <div className="mt-4 grid grid-cols-3 gap-3">
              {[
                { k: "DAU", v: "٤٢k" },
                { k: "MAU", v: "٣١٠k" },
                { k: "Retention", v: "٦٨٪" },
                { k: "Churn", v: "٤٪" },
                { k: "LTV", v: "‎$٨٤" },
                { k: "CAC", v: "‎$١٢" },
              ].map((m) => (
                <div key={m.k} className="rounded-2xl bg-brand-50 p-3 text-center">
                  <div className="font-display text-xl font-extrabold text-brand-600">{m.v}</div>
                  <div className="text-[11px] font-semibold text-ink-soft">{m.k}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Pricing */}
      <Section id="pricing" eyebrow="نموذج الأعمال" title="أسعار تناسب الجميع" desc="من الطفل إلى المدرسة إلى الترخيص الحكومي.">
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {PRICING.map((p) => (
            <div key={p.t} className={cn("card-soft relative p-6", p.feat && "ring-2 ring-brand-500")}>
              {p.feat && <span className="absolute -top-3 right-6 chip bg-brand-500 text-white">الأكثر شيوعاً</span>}
              <div className="text-3xl">{p.icon}</div>
              <h3 className="font-display mt-2 text-xl font-extrabold text-ink">{p.t}</h3>
              <div className="font-display mt-2 text-3xl font-extrabold text-brand-600">{p.price}</div>
              <ul className="mt-4 space-y-2 text-sm text-ink-soft">
                {p.items.map((i) => (
                  <li key={i} className="flex items-center gap-2"><span className="text-mint-500">✓</span> {i}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* Roadmap */}
      <Section id="roadmap" eyebrow="خارطة الطريق" title="رحلة ٢٤ شهراً نحو العالمية">
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {ROADMAP.map((r, i) => (
            <div key={r.phase} className="card-soft p-5">
              <div className="flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-500 font-display text-sm font-extrabold text-white">{i + 1}</span>
                <span className="text-xs font-bold text-brand-600">{r.when}</span>
              </div>
              <h3 className="font-display mt-3 font-bold text-ink">{r.phase}</h3>
              <p className="mt-1 text-sm text-ink-soft">{r.items}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Tech stack */}
      <Section eyebrow="البنية التقنية" title="معمارية معيارية قابلة للتوسّع">
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[
            { h: "الواجهة", items: ["React", "React Native", "Flutter"], c: "bg-brand-50 text-brand-700" },
            { h: "الخادم", items: ["Node.js", "NestJS", "Python"], c: "bg-mint-50 text-mint-600" },
            { h: "الذكاء الاصطناعي", items: ["Gemini", "GPT-4o", "Claude", "Whisper"], c: "bg-sun-50 text-sun-600" },
            { h: "قواعد البيانات", items: ["PostgreSQL", "Redis", "Vector DB"], c: "bg-coral-400/10 text-coral-600" },
            { h: "السحابة", items: ["Google Cloud", "AWS", "Azure"], c: "bg-sky-300/10 text-sky-500" },
          ].map((s) => (
            <div key={s.h} className="card-soft p-4">
              <h3 className={cn("font-display mb-2 text-sm font-bold", s.c.split(" ")[1])}>{s.h}</h3>
              <div className="flex flex-wrap gap-1.5">
                {s.items.map((i) => (
                  <span key={i} className={cn("rounded-lg px-2 py-1 text-xs font-semibold", s.c)}>{i}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Final CTA */}
      <section className="relative overflow-hidden bg-gradient-to-l from-brand-600 via-brand-500 to-coral-500 py-20 text-center text-white">
        <div className="bg-grid absolute inset-0 opacity-20" />
        <div className="relative mx-auto max-w-2xl px-4">
          <div className="text-6xl">🦊</div>
          <h2 className="font-display mt-4 text-3xl font-extrabold sm:text-4xl">ابدأ مغامرة العربية اليوم</h2>
          <p className="mt-3 text-white/85">انضم لآلاف الأسر والمدارس التي تختار نون لتعليم أبنائها لغة المستقبل.</p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Link href="/app" className="rounded-full bg-white px-7 py-3 font-display font-extrabold text-brand-700 shadow-xl transition hover:-translate-y-1">🚀 ابدأ مجاناً</Link>
            <Link href="/teacher" className="rounded-full bg-white/15 px-7 py-3 font-display font-extrabold text-white ring-2 ring-white/40 transition hover:-translate-y-1">تواصل مع المدارس</Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}

function Section({ id, eyebrow, title, desc, children }: { id?: string; eyebrow?: string; title: string; desc?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <SectionTitle eyebrow={eyebrow} title={title} desc={desc} center />
      {children}
    </section>
  );
}

const FEATURES = [
  { icon: "🤖", t: "المعلّم الذكي", d: "يشرح ويبسّط ويعيد الشرح ويقيّم الإجابات فوراً بأسلوب طفولي محبّب.", bg: "bg-brand-100" },
  { icon: "📖", t: "مولّد القصص", d: "قصص مخصّصة لكل طفل حسب العمر والمستوى والاهتمامات والكلمات الجديدة.", bg: "bg-sun-100" },
  { icon: "🎮", t: "مولّد الألعاب", d: "ألعاب مفردات ونحو وقراءة وكتابة تُنشأ تلقائياً لكل مهارة.", bg: "bg-mint-100" },
  { icon: "🎤", t: "التعرف على الصوت", d: "يصحّح مخارج الحروف والتشكيل وسرعة القراءة بدقة عالية.", bg: "bg-coral-400/15" },
  { icon: "💬", t: "مساعد المحادثة", d: "شخصية ذكية تتحدث العربية مع الطفل وتصحّح وتشجّع.", bg: "bg-sky-300/15" },
  { icon: "📊", t: "تحليل الأداء", d: "يقيس التركيز والكلمات المكتسبة والأخطاء ويبني خطة شخصية.", bg: "bg-brand-100" },
  { icon: "📚", t: "القراءة بالـ AI", d: "يقيّم الطلاقة والوقفات ومخارج الحروف ويعطي تقريراً.", bg: "bg-mint-100" },
  { icon: "✍️", t: "الخط العربي", d: "تتبّع الحروف والتدريب على الكتابة الصحيحة بشكل ممتع.", bg: "bg-sun-100" },
  { icon: "🇦🇪", t: "الهوية والتراث", d: "محتوى ثقافي إماراتي يغرس القيم الوطنية والهوية.", bg: "bg-coral-400/15" },
];

const AI_AGENTS = [
  { icon: "🧑‍🏫", t: "معلم ذكي", d: "يشرح الدروس ويعيد الشرح ويبسّط المعلومة." },
  { icon: "✍️", t: "كاتب قصص", d: "يولّد قصصاً مخصّصة لكل طفل." },
  { icon: "🎲", t: "مصمّم ألعاب", d: "ينشئ ألعاباً تعليمية تلقائياً." },
  { icon: "🗣️", t: "شريك محادثة", d: "يتحدث ويصحّح النطق." },
  { icon: "🔬", t: "محلّل أداء", d: "يبني خططاً تعليمية شخصية." },
  { icon: "🎧", t: "مقيّم قراءة", d: "يحلّل الطلاقة ومخارج الحروف." },
];

const GAMES = [
  { icon: "🏙️", t: "مدينة عربية", c: "from-brand-500 to-brand-700" },
  { icon: "🍽️", t: "المطعم", c: "from-sun-400 to-sun-600" },
  { icon: "🛒", t: "السوق", c: "from-mint-400 to-mint-600" },
  { icon: "🏥", t: "المستشفى", c: "from-coral-400 to-coral-600" },
  { icon: "✈️", t: "المطار", c: "from-sky-400 to-sky-600" },
  { icon: "🚀", t: "الفضاء", c: "from-brand-600 to-coral-500" },
  { icon: "🏝️", t: "البحث عن كنز", c: "from-sun-500 to-coral-500" },
  { icon: "🗝️", t: "غرفة هروب", c: "from-brand-700 to-brand-500" },
];

const REWARDS = [
  { icon: "⚡", t: "نقاط XP", d: "لكل إنجاز نقاط ترفع المستوى." },
  { icon: "🪙", t: "عملات وجواهر", d: "اعرف واشترِ في المتجر." },
  { icon: "🏅", t: "شارات وكؤوس", d: "اجمع إنجازاتك." },
  { icon: "🦊", t: "شخصيات", d: "افتح أبطالاً جدداً." },
];

const AUDIENCE = ["أطفال ٣–٥", "أطفال ٦–٨", "أطفال ٩–١٢", "مراهقون", "مقيمون", "مدارس", "حضانات", "معلمون", "أولياء أمور", "مراكز تعليم العربية"];

const PRICING = [
  { icon: "🌱", t: "مجاني", price: "٠ د.إ", feat: false, items: ["حروف وأول الكلمات", "ألعاب أساسية", "متابعة بسيطة"] },
  { icon: "⭐", t: "اشتراك عائلي", price: "٢٩ د.إ/شهر", feat: true, items: ["كل الدروس والألعاب", "المعلم والقصص الذكية", "لوحة أولياء الأمور", "تصحيح النطق"] },
  { icon: "🏫", t: "مدارس ومؤسسات", price: "حسب الطلب", feat: false, items: ["إدارة فصول وواجبات", "تحليلات وتقارير", "ترخيص حكومي", "دعم متخصّص"] },
];

const ROADMAP = [
  { when: "أشهر ١–٤", phase: "الاكتشاف والتصميم", items: "أبحاث UX، نظام تصميم، MVP للنموذج الأولي." },
  { when: "أشهر ٥–٨", phase: "Alpha & MVP", items: "إطلاق تجريبي محدود، اختبار المعلم الذكي والألعاب." },
  { when: "أشهر ٩–١٢", phase: "Beta ثم الإنتاج", items: "إطلاق رسمي في الإمارات مع تحسينات بالذكاء الاصطناعي." },
  { when: "أشهر ١٣–٢٤", phase: "التوسّع العالمي", items: "الخليج، الوطن العربي، ثم العالم، ومناهج إضافية." },
];
