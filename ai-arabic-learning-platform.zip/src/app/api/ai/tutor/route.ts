import { NextRequest, NextResponse } from "next/server";
import { tutorReply } from "@/lib/ai";

export async function POST(req: NextRequest) {
  try {
    const { message, history } = await req.json();
    if (!message || typeof message !== "string") {
      return NextResponse.json({ error: "message required" }, { status: 400 });
    }
    const reply = await tutorReply(message, Array.isArray(history) ? history : []);
    return NextResponse.json(reply);
  } catch {
    return NextResponse.json(
      { text: "عذراً، حدث خطأ بسيط. حاول مرة أخرى!", source: "local" },
      { status: 200 },
    );
  }
}
