import { NextRequest, NextResponse } from "next/server";
import { getPerformanceStats } from "@/lib/data";
import { analyzePerformance } from "@/lib/ai";

export async function GET(req: NextRequest) {
  try {
    const learnerId = Number(req.nextUrl.searchParams.get("learnerId")) || 1;
    const stats = await getPerformanceStats(learnerId);
    const analysis = await analyzePerformance(stats);
    return NextResponse.json({ ...analysis, stats });
  } catch {
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}
