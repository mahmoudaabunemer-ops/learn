import { NextRequest, NextResponse } from "next/server";
import { generateStory } from "@/lib/ai";

export async function POST(req: NextRequest) {
  try {
    const { theme, level, age, words } = await req.json();
    const story = await generateStory({
      theme: String(theme ?? "forest"),
      level: String(level ?? "beginner"),
      age: Number(age) || 7,
      words: Array.isArray(words) ? words.slice(0, 6) : [],
    });
    return NextResponse.json(story);
  } catch {
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}
