import { NextRequest, NextResponse } from "next/server";
import { recordLessonCompletion } from "@/lib/data";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = await recordLessonCompletion({
      learnerId: Number(body.learnerId) || 1,
      slug: String(body.slug ?? ""),
      accuracy: Math.max(0, Math.min(100, Number(body.accuracy) || 0)),
      xp: Math.max(0, Number(body.xp) || 0),
      coins: Math.max(0, Number(body.coins) || 0),
      stars: Math.max(0, Math.min(3, Number(body.stars) || 1)),
      gameType: String(body.gameType ?? "quiz"),
      durationSec: Math.max(0, Number(body.durationSec) || 0),
    });
    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
