import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Baloo_Bhaijaan_2, Tajawal } from "next/font/google";
import "./globals.css";

const display = Baloo_Bhaijaan_2({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-display",
  display: "swap",
});

const body = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "700", "800"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: "نون · عالم العربية الذكي | AI Arabic Learning Platform",
  description:
    "منصة عالمية لتعليم اللغة العربية بالذكاء الاصطناعي للأطفال والمقيمين. قصص وألعاب ومعلم ذكي تتكيف مع كل طالب. متوافقة مع المنهج الإماراتي.",
  keywords: [
    "تعليم العربية",
    "ذكاء اصطناعي",
    "أطفال",
    "المنهج الإماراتي",
    "Arabic learning",
    "AI tutor",
  ],
  openGraph: {
    title: "نون · عالم العربية الذكي",
    description: "تعلّم العربية بالذكاء الاصطناعي عبر قصص وألعاب تفاعلية.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${display.variable} ${body.variable}`}>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
