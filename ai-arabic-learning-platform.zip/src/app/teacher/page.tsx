import Link from "next/link";
import { getLeaderboard, getLearner } from "@/lib/data";
import { Blobs } from "@/components/ui";
import { cn, fmt } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function TeacherPage() {
  const [students, me] = await Promise.all([getLeaderboard(), getLearner()]);

  const totalXp = students.reduce((s, x) => s + x.xp, 0);
  const totalLessons = students.reduce((s, x) => s + x.lessonsCompleted, 0);
  const avgCompletion = students.length ? Math.round(totalLessons / students.length) : 0;

  return (
    <div className="min-h-screen">
      <Blobs />
      <header className="sticky top-0 z-40 glass border-b border-white/50">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-coral-500 font-display text-xl font-extrabold text-white">ن</span>
            <span className="font-display text-lg font-extrabold text-ink">نون · لوحة المعلّم</span>
          </Link>
          <Link href="/app" className="btn-ghost !px-4 !py-2 text-sm">واجهة الطالب ←</Link>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-extrabold text-ink">فصل الصف الثالث (ب)</h1>
            <p className="text-sm text-ink-soft">مدرسة الأمير الابتدائية · الفصل الدراسي الأول</p>
          </div>
          <button className="btn-primary !py-2 text-sm">➕ إضافة واجب بالذكاء الاصطناعي</button>
        </div>

        {/* KPI */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { icon: "👨‍🎓", v: students.length, l: "عدد الطلاب", c: "text-brand-600" },
            { icon: "✅", v: avgCompletion, l: "متوسط الدروس", c: "text-mint-600" },
            { icon: "⭐", v: fmt(totalXp), l: "مجموع النقاط", c: "text-sun-600" },
            { icon: "🎯", v: "84%", l: "متوسط الإنجاز", c: "text-coral-600" },
          ].map((k) => (
            <div key={k.l} className="card-soft p-4">
              <div className="text-2xl">{k.icon}</div>
              <div className={cn("font-display mt-1 text-2xl font-extrabold", k.c)}>{k.v}</div>
              <div className="text-xs font-semibold text-ink-soft">{k.l}</div>
            </div>
          ))}
        </div>

        {/* students table */}
        <div className="card-soft overflow-hidden">
          <div className="flex items-center justify-between border-b border-brand-50 p-4">
            <h2 className="font-display text-lg font-extrabold text-ink">👨‍🏫 أداء الطلاب</h2>
            <span className="text-xs font-semibold text-ink-soft">مقارنة وتصنيف</span>
          </div>
          <div className="divide-y divide-brand-50">
            {students.map((s, i) => {
              const pct = Math.min(100, Math.round((s.lessonsCompleted / 12) * 100));
              const isMe = s.learnerId === me.id;
              return (
                <div key={s.learnerId} className={cn("flex items-center gap-3 p-4", isMe && "bg-brand-50")}>
                  <span className="w-5 text-center font-bold text-ink-soft">{i + 1}</span>
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-brand-100 text-xl">{s.avatar}</span>
                  <div className="w-24">
                    <div className="font-bold text-ink">{s.name}</div>
                    <div className="text-xs text-ink-soft">{s.lessonsCompleted} درس</div>
                  </div>
                  <div className="flex-1">
                    <div className="h-2.5 overflow-hidden rounded-full bg-brand-100">
                      <div className="h-full rounded-full bg-gradient-to-l from-brand-500 to-mint-400" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                  <span className="w-14 text-left font-display font-bold text-brand-600">⭐ {fmt(s.xp)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* assignments + AI tools */}
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="card-soft p-5">
            <h2 className="font-display text-lg font-extrabold text-ink">📋 الواجبات</h2>
            <div className="mt-3 space-y-3">
              {[
                { t: "درس الحيوانات", due: "غداً", done: 8, total: 12, c: "bg-brand-500" },
                { t: "تهجئة الأرقام", due: "بعد غد", done: 5, total: 12, c: "bg-mint-500" },
                { t: "قصة تراث الإمارات", due: "الأحد", done: 3, total: 12, c: "bg-sun-500" },
              ].map((a) => (
                <div key={a.t} className="rounded-2xl bg-brand-50 p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-ink">{a.t}</span>
                    <span className="text-xs font-semibold text-coral-500">⏰ {a.due}</span>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-white">
                      <div className={cn("h-full rounded-full", a.c)} style={{ width: `${(a.done / a.total) * 100}%` }} />
                    </div>
                    <span className="text-xs font-bold text-ink-soft">{a.done}/{a.total}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card-soft p-5">
            <h2 className="font-display text-lg font-extrabold text-ink">🤖 أدوات الذكاء الاصطناعي</h2>
            <p className="mt-1 text-sm text-ink-soft">أنشئ المحتوى في ثوانٍ</p>
            <div className="mt-4 grid gap-3">
              {[
                { icon: "✍️", t: "مولّد الدروس", d: "أنشئ درساً كاملاً بمستوى محدد" },
                { icon: "📝", t: "مولّد الاختبارات", d: "أسئلة تلقائية وتصحيح فوري" },
                { icon: "📖", t: "مولّد القصص", d: "قصص تربوية مخصّصة للفصل" },
                { icon: "📊", t: "تحليل الأداء", d: "تقارير ذكية لكل طالب" },
              ].map((t) => (
                <button key={t.t} className="flex items-center gap-3 rounded-2xl bg-brand-50 p-3 text-right transition hover:-translate-y-0.5 hover:bg-brand-100">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-white text-2xl shadow-sm">{t.icon}</span>
                  <div>
                    <div className="font-bold text-brand-700">{t.t}</div>
                    <div className="text-xs text-ink-soft">{t.d}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
