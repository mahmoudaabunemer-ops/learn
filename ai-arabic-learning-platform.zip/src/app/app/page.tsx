import Link from "next/link";
import { getLearner, getLessons, getProgressMap } from "@/lib/data";
import { ProgressRing, Mascot } from "@/components/ui";
import { UNITS } from "@/lib/curriculum";
import { levelFromXp, rankTitle, cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const learner = await getLearner();
  const [lessons, progress] = await Promise.all([getLessons(), getProgressMap(learner.id)]);

  const lv = levelFromXp(learner.xp);
  const dailyPct = Math.min(100, Math.round((learner.todayMinutes / learner.dailyGoalMinutes) * 100));
  const sorted = [...lessons].sort((a, b) => a.unitId - b.unitId || a.order - b.order);

  // unlock chain
  let chainBroken = false;
  const decorated = sorted.map((l, i) => {
    const prevDone = i === 0 || progress[sorted[i - 1].id]?.completed;
    const unlocked = !chainBroken && (i === 0 || prevDone);
    if (!unlocked) chainBroken = true;
    const pr = progress[l.id];
    return { ...l, unlocked, completed: pr?.completed ?? false, stars: pr?.stars ?? 0 };
  });

  const nextLesson = decorated.find((l) => !l.completed && l.unlocked);

  return (
    <div className="space-y-8">
      {/* Greeting + daily goal */}
      <section className="grid gap-4 lg:grid-cols-[1fr_auto]">
        <div className="card-soft flex flex-wrap items-center gap-5 p-5">
          <Mascot size={64} />
          <div className="flex-1">
            <p className="text-sm font-semibold text-ink-soft">أهلاً بعودتك يا بطل! 👋</p>
            <h1 className="font-display text-2xl font-extrabold text-ink">{learner.name}</h1>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-sm font-bold">
              <span className="chip bg-brand-50 text-brand-700">المستوى {lv.level} · {rankTitle(lv.level)}</span>
              <span className="chip bg-coral-400/10 text-coral-600">🔥 {learner.streak} يوم</span>
            </div>
          </div>
          {nextLesson ? (
            <Link href={`/app/learn/${nextLesson.slug}`} className="btn-primary">
              ▶ أكمل: {nextLesson.title}
            </Link>
          ) : null}
        </div>

        <div className="card-soft flex items-center gap-4 p-5">
          <ProgressRing pct={dailyPct} size={96} stroke={10} color="#14b8a6">
            <div className="text-center">
              <div className="font-display text-xl font-extrabold text-mint-600">{learner.todayMinutes}</div>
              <div className="text-[10px] font-bold text-ink-soft">/ {learner.dailyGoalMinutes} د</div>
            </div>
          </ProgressRing>
          <div>
            <p className="font-display font-bold text-ink">الهدف اليومي</p>
            <p className="text-sm text-ink-soft">{dailyPct >= 100 ? "اكتمل اليوم! 🎉" : "استمر، أنت قريب!"}</p>
            <p className="mt-1 text-xs font-semibold text-mint-600">{learner.totalWordsLearned} كلمة مكتسبة</p>
          </div>
        </div>
      </section>

      {/* Quick actions */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { href: "/app/tutor", icon: "🤖", t: "المعلّم الذكي", c: "from-brand-500 to-brand-700" },
          { href: "/app/stories", icon: "📖", t: "قصة جديدة", c: "from-sun-400 to-sun-600" },
          { href: "/app/leaderboard", icon: "🏆", t: "المتصدرون", c: "from-mint-400 to-mint-600" },
          { href: "/app/shop", icon: "🛍️", t: "المتجر", c: "from-coral-400 to-coral-600" },
        ].map((a) => (
          <Link key={a.href} href={a.href} className={`group relative overflow-hidden rounded-3xl bg-gradient-to-br ${a.c} p-4 text-white shadow-lg transition hover:-translate-y-1`}>
            <div className="text-3xl">{a.icon}</div>
            <div className="font-display mt-2 font-bold">{a.t}</div>
          </Link>
        ))}
      </section>

      {/* Learning path by unit */}
      {UNITS.map((unit) => {
        const unitLessons = decorated.filter((l) => l.unitId === unit.id);
        if (unitLessons.length === 0) return null;
        return (
          <section key={unit.id}>
            <div className="mb-4 flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-2xl text-2xl shadow" style={{ background: `${unit.color}22` }}>
                {unit.emoji}
              </span>
              <div>
                <h2 className="font-display text-xl font-extrabold text-ink">{unit.title}</h2>
                <p className="text-sm text-ink-soft">{unit.subtitle}</p>
              </div>
            </div>

            <div className="relative grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {unitLessons.map((l) => (
                <LessonCard key={l.slug} lesson={l} unitColor={unit.color} />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}

function LessonCard({
  lesson,
  unitColor,
}: {
  lesson: { slug: string; title: string; subtitle: string | null; emoji: string; color: string; difficulty: number; xpReward: number; unlocked: boolean; completed: boolean; stars: number };
  unitColor: string;
}) {
  return (
    <Link
      href={lesson.unlocked ? `/app/learn/${lesson.slug}` : "#"}
      className={cn(
        "card-soft group relative flex items-center gap-4 p-4 transition",
        lesson.unlocked ? "hover:-translate-y-1 hover:shadow-xl" : "opacity-60",
      )}
      aria-disabled={!lesson.unlocked}
    >
      <span
        className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-3xl shadow-inner"
        style={{ background: `${lesson.color}1a` }}
      >
        {lesson.unlocked ? lesson.emoji : "🔒"}
      </span>
      <div className="min-w-0 flex-1">
        <h3 className="font-display font-bold text-ink">{lesson.title}</h3>
        <p className="truncate text-xs text-ink-soft">{lesson.subtitle}</p>
        <div className="mt-1 flex items-center gap-1 text-xs">
          {Array.from({ length: 3 }).map((_, i) => (
            <span key={i} className={i < lesson.stars ? "" : "opacity-20"}>
              ⭐
            </span>
          ))}
          <span className="ml-1 rounded-full bg-brand-50 px-2 py-0.5 text-[10px] font-bold text-brand-600">
            +{lesson.xpReward} XP
          </span>
        </div>
      </div>
      {lesson.completed && <span className="absolute left-3 top-3 text-mint-500">✓</span>}
      <span className="text-brand-300 transition group-hover:translate-x-1">‹</span>
    </Link>
  );
}
