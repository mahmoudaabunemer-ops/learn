"use client";

import { useEffect, useRef, useState } from "react";
import { Mascot } from "@/components/ui";
import { speak } from "@/components/games";
import { cn } from "@/lib/utils";

type Msg = { role: "learner" | "tutor"; content: string };

const SUGGESTIONS = ["مرحباً!", "علّمني كلمة جديدة", "كيف أنطق حرف العين؟", "أعطني جملة سهلة"];

const GREETING: Msg = {
  role: "tutor",
  content: "مرحباً يا صديقي! 🦊 أنا معلّمك الذكي «نون». اسألني أي سؤال، أو اطلب أن نتعلّم كلمة أو جملة جديدة معاً!",
};

export default function TutorPage() {
  const [messages, setMessages] = useState<Msg[]>([GREETING]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || loading) return;
    setInput("");
    setMessages((m) => [...m, { role: "learner", content }]);
    setLoading(true);
    try {
      const res = await fetch("/api/ai/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content, history: messages }),
      });
      const data = await res.json();
      const reply: string = data.text ?? "عذراً، لم أفهم. حاول مرة أخرى!";
      setMessages((m) => [...m, { role: "tutor", content: reply }]);
      setTimeout(() => speak(reply), 200);
    } catch {
      setMessages((m) => [...m, { role: "tutor", content: "حدث خطأ بسيط، حاول مجدداً 🙏" }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-9rem)] max-w-2xl flex-col">
      <div className="mb-4 flex items-center gap-3">
        <Mascot size={56} />
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">المعلّم الذكي نون</h1>
          <p className="text-sm text-ink-soft">يتحدّث العربية معك ويصحّح أخطاءك ويشجّعك 💬</p>
        </div>
      </div>

      <div className="card-soft flex-1 overflow-y-auto p-4">
        <div className="space-y-3">
          {messages.map((m, i) => (
            <div key={i} className={cn("flex items-end gap-2", m.role === "learner" ? "flex-row-reverse" : "")}>
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-100 text-lg">
                {m.role === "tutor" ? "🦊" : "🧒"}
              </span>
              <div
                className={cn(
                  "max-w-[78%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm",
                  m.role === "tutor"
                    ? "rounded-bl-sm bg-white text-ink"
                    : "rounded-br-sm bg-brand-500 text-white",
                )}
              >
                {m.content}
                {m.role === "tutor" && (
                  <button
                    onClick={() => speak(m.content)}
                    className="ms-2 align-middle text-brand-400 hover:text-brand-600"
                    aria-label="استمع"
                  >
                    🔊
                  </button>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex items-end gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-100 text-lg">🦊</span>
              <div className="rounded-2xl rounded-bl-sm bg-white px-4 py-3 shadow-sm">
                <span className="inline-flex gap-1">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-brand-300" style={{ animationDelay: "0ms" }} />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-brand-300" style={{ animationDelay: "150ms" }} />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-brand-300" style={{ animationDelay: "300ms" }} />
                </span>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>
      </div>

      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => send(s)}
            className="shrink-0 rounded-full bg-white px-3 py-1.5 text-xs font-bold text-brand-700 shadow ring-1 ring-brand-100 transition hover:bg-brand-50"
          >
            {s}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="mt-2 flex gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اكتب رسالتك بالعربية…"
          className="flex-1 rounded-full border-2 border-brand-200 bg-white px-5 py-3 text-sm font-medium outline-none transition focus:border-brand-400"
        />
        <button type="submit" disabled={loading} className="btn-primary !px-5 disabled:opacity-50">
          إرسال ➤
        </button>
      </form>
    </div>
  );
}
