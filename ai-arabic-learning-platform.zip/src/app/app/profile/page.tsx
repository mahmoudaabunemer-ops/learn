import { getLearner, getEarnedAchievements, getPerformanceStats } from "@/lib/data";
import { ProgressRing } from "@/components/ui";
import { levelFromXp, rankTitle, cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const [learner, badges, stats] = await Promise.all([
    getLearner(),
    getEarnedAchievements(learner_placeholder()),
    getPerformanceStats(1),
  ]);
  function learner_placeholder() {
    return 1;
  }
  const lv = levelFromXp(learner.xp);
  const goalPct = Math.min(100, Math.round((learner.todayMinutes / learner.dailyGoalMinutes) * 100));

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="card-soft flex flex-col items-center gap-4 p-6 text-center sm:flex-row sm:text-right">
        <div className="grid h-24 w-24 place-items-center rounded-3xl bg-brand-100 text-6xl ring-4 ring-brand-200">{learner.avatar}</div>
        <div className="flex-1">
          <h1 className="font-display text-2xl font-extrabold text-ink">{learner.name}</h1>
          <p className="text-sm text-ink-soft">{learner.age} سنوات · المنهج الإماراتي</p>
          <div className="mt-2 flex flex-wrap justify-center gap-2 sm:justify-start">
            <span className="chip bg-brand-50 text-brand-700">المستوى {lv.level} · {rankTitle(lv.level)}</span>
            <span className="chip bg-coral-400/10 text-coral-600">🔥 {learner.streak}</span>
          </div>
        </div>
        <ProgressRing pct={goalPct} size={88} stroke={9} color="#14b8a6">
          <div className="text-center">
            <div className="font-display text-base font-extrabold text-mint-600">{learner.todayMinutes}</div>
            <div className="text-[9px] text-ink-soft">/ {learner.dailyGoalMinutes}د</div>
          </div>
        </ProgressRing>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { i: "⚡", v: learner.xp, l: "نقاط الخبرة", c: "text-brand-600" },
          { i: "🪙", v: learner.coins, l: "العملات", c: "text-sun-600" },
          { i: "💎", v: learner.gems, l: "الجواهر", c: "text-sky-500" },
          { i: "❤️", v: learner.hearts, l: "القلوب", c: "text-coral-600" },
        ].map((s) => (
          <div key={s.l} className="card-soft p-4 text-center">
            <div className="text-2xl">{s.i}</div>
            <div className={cn("font-display text-xl font-extrabold", s.c)}>{s.v}</div>
            <div className="text-[11px] font-semibold text-ink-soft">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="card-soft p-5">
        <h2 className="font-display text-lg font-extrabold text-ink">🏆 الإنجازات</h2>
        <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-6">
          {(badges.length ? badges : FALLBACK).map((b, i) => (
            <div key={i} className="flex flex-col items-center rounded-2xl bg-brand-50 p-3 text-center">
              <span className="text-3xl">{b.emoji}</span>
              <span className="mt-1 text-[11px] font-bold text-ink">{b.title}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 rounded-2xl bg-mint-50 p-4 text-sm text-ink">
          <span className="font-bold text-mint-600">🎯 إحصائية اليوم:</span> تعلّمتَ {learner.totalWordsLearned} كلمة بدقة {stats.accuracy}%!
        </div>
      </div>
    </div>
  );
}

const FALLBACK = [
  { emoji: "🌟", title: "البداية الموفقة" },
  { emoji: "🔥", title: "سلسلة ٧ أيام" },
  { emoji: "📖", title: "قارئ صغير" },
  { emoji: "🏅", title: "٥٠ كلمة" },
  { emoji: "🎯", title: "دقة عالية" },
  { emoji: "🚀", title: "مستكشف" },
];
