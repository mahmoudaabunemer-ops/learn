import type { ReactNode } from "react";
import { TopBar, BottomNav } from "@/components/AppChrome";
import { Blobs } from "@/components/ui";
import { getLearner } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const learner = await getLearner();
  return (
    <div className="min-h-screen pb-20">
      <Blobs />
      <TopBar learner={learner} />
      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6">{children}</main>
      <BottomNav />
    </div>
  );
}
