"use client";

import { useState } from "react";
import { Mascot } from "@/components/ui";
import { speak } from "@/components/games";
import { cn } from "@/lib/utils";
import type { StoryResult } from "@/lib/ai";

const THEMES = [
  { id: "forest", label: "غابة الحيوانات", emoji: "🌳" },
  { id: "space", label: "رحلة فضائية", emoji: "🚀" },
  { id: "uae", label: "صحراء الإمارات", emoji: "🦅" },
];

const WORD_POOL = ["قطة", "أسد", "شمس", "قمر", "جمل", "نخلة", "صقر", "صاروخ", "نجمة", "قرفة"];

const LEVELS = [
  { id: "beginner", label: "مبتدئ" },
  { id: "elementary", label: "ابتدائي" },
  { id: "intermediate", label: "متوسط" },
];

export default function StoriesPage() {
  const [theme, setTheme] = useState("forest");
  const [level, setLevel] = useState("beginner");
  const [age, setAge] = useState(7);
  const [words, setWords] = useState<string[]>(["قطة", "شمس"]);
  const [story, setStory] = useState<StoryResult | null>(null);
  const [loading, setLoading] = useState(false);

  function toggleWord(w: string) {
    setWords((cur) => (cur.includes(w) ? cur.filter((x) => x !== w) : [...cur, w]));
  }

  async function generate() {
    setLoading(true);
    setStory(null);
    try {
      const res = await fetch("/api/ai/story", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme, level, age, words }),
      });
      const data = (await res.json()) as StoryResult;
      setStory(data);
    } catch {
      setStory(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-5 flex items-center gap-3">
        <Mascot size={56} />
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">مولّد القصص الذكي</h1>
          <p className="text-sm text-ink-soft">قصص تُكتب خصيصاً لك بمفرداتك ومستواك 📖✨</p>
        </div>
      </div>

      <div className="card-soft space-y-5 p-5">
        {/* theme */}
        <div>
          <p className="mb-2 text-sm font-bold text-ink">اختر عالم القصة</p>
          <div className="grid grid-cols-3 gap-2">
            {THEMES.map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={cn(
                  "rounded-2xl p-3 text-center transition",
                  theme === t.id ? "bg-brand-500 text-white shadow-lg" : "bg-brand-50 text-brand-700",
                )}
              >
                <div className="text-2xl">{t.emoji}</div>
                <div className="mt-1 text-xs font-bold">{t.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* level + age */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="mb-2 text-sm font-bold text-ink">المستوى</p>
            <div className="flex gap-2">
              {LEVELS.map((l) => (
                <button
                  key={l.id}
                  onClick={() => setLevel(l.id)}
                  className={cn(
                    "flex-1 rounded-xl px-2 py-2 text-xs font-bold transition",
                    level === l.id ? "bg-mint-500 text-white" : "bg-mint-50 text-mint-600",
                  )}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-sm font-bold text-ink">العمر: {age} سنوات</p>
            <input
              type="range"
              min={3}
              max={12}
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="w-full accent-brand-500"
            />
          </div>
        </div>

        {/* words */}
        <div>
          <p className="mb-2 text-sm font-bold text-ink">كلمات تريد أن تظهر في القصة</p>
          <div className="flex flex-wrap gap-2">
            {WORD_POOL.map((w) => (
              <button
                key={w}
                onClick={() => toggleWord(w)}
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-bold transition",
                  words.includes(w) ? "bg-sun-500 text-white" : "bg-sun-50 text-sun-600",
                )}
              >
                {w}
              </button>
            ))}
          </div>
        </div>

        <button onClick={generate} disabled={loading} className="btn-primary w-full disabled:opacity-60">
          {loading ? "✨ يكتب قصتك…" : "📖 اكتب لي قصة!"}
        </button>
      </div>

      {/* result */}
      {loading && (
        <div className="card-soft mt-5 space-y-3 p-6">
          {[90, 70, 80].map((w, i) => (
            <div key={i} className="h-4 animate-pulse rounded-full bg-brand-100" style={{ width: `${w}%` }} />
          ))}
        </div>
      )}

      {story && !loading && (
        <div className="card-soft mt-5 overflow-hidden">
          <div className="flex items-center justify-between bg-gradient-to-l from-brand-500 to-coral-500 p-5 text-white">
            <h2 className="font-display text-xl font-extrabold">{story.title}</h2>
            <button
              onClick={() => speak(story.paragraphs.join(" "))}
              className="grid h-10 w-10 place-items-center rounded-full bg-white/20 text-xl"
            >
              🔊
            </button>
          </div>
          <div className="space-y-3 p-5">
            {story.paragraphs.map((p, i) => (
              <p key={i} className="text-lg leading-loose text-ink">
                {p}
              </p>
            ))}

            {story.vocabulary?.length ? (
              <div className="mt-4">
                <p className="mb-2 text-sm font-bold text-brand-700">📌 مفردات القصة</p>
                <div className="flex flex-wrap gap-2">
                  {story.vocabulary.map((v, i) => (
                    <button
                      key={i}
                      onClick={() => speak(v.ar)}
                      className="flex items-center gap-2 rounded-2xl bg-brand-50 px-3 py-2 text-sm"
                    >
                      <span className="text-xl">{v.emoji}</span>
                      <span className="font-bold text-ink">{v.ar}</span>
                      <span className="text-xs text-ink-soft">{v.en}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : null}

            {story.questions?.length ? (
              <div className="mt-4">
                <p className="mb-2 text-sm font-bold text-mint-600">❓ أسئلة الفهم</p>
                <div className="space-y-3">
                  {story.questions.map((q, i) => (
                    <StoryQuestion key={i} q={q} />
                  ))}
                </div>
              </div>
            ) : null}

            <p className="mt-2 text-center text-xs text-ink-soft">
              {story.source === "ai" ? "✦ مولّدة بالذكاء الاصطناعي" : "✦ من مكتبة نون الذكية"}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function StoryQuestion({ q }: { q: { question: string; options: string[]; answer: number } }) {
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div className="rounded-2xl bg-mint-50 p-3">
      <p className="mb-2 text-sm font-bold text-ink">{q.question}</p>
      <div className="grid grid-cols-1 gap-2">
        {q.options.map((o, i) => {
          const state = picked === null ? "idle" : i === q.answer ? "right" : picked === i ? "wrong" : "dim";
          return (
            <button
              key={i}
              disabled={picked !== null}
              onClick={() => setPicked(i)}
              className={cn(
                "rounded-xl px-3 py-2 text-right text-sm font-semibold transition",
                state === "idle" && "bg-white text-ink hover:ring-2 hover:ring-mint-300",
                state === "right" && "bg-mint-500 text-white",
                state === "wrong" && "bg-coral-500 text-white",
                state === "dim" && "bg-white/50 text-ink-soft opacity-60",
              )}
            >
              {o}
            </button>
          );
        })}
      </div>
    </div>
  );
}
