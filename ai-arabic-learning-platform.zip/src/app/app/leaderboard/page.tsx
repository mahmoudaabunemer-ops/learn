import { getLeaderboard, getLearner } from "@/lib/data";
import { cn, fmt } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function Leaderboard() {
  const [rows, me] = await Promise.all([getLeaderboard(), getLearner()]);

  const podiumOrder = [rows[1], rows[0], rows[2]].filter(Boolean);
  const podiumMeta = [
    { h: "h-24", medal: "🥈", ring: "ring-slate-300" },
    { h: "h-32", medal: "🥇", ring: "ring-sun-400" },
    { h: "h-20", medal: "🥉", ring: "ring-coral-300" },
  ];

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-5 text-center">
        <h1 className="font-display text-2xl font-extrabold text-ink">🏆 لوحة المتصدّرين</h1>
        <p className="text-sm text-ink-soft">نافِس أصدقاءك واصعد إلى القمة!</p>
      </div>

      {/* podium */}
      <div className="mb-6 flex items-end justify-center gap-3">
        {podiumOrder.map((r, i) => (
          <div key={r.learnerId} className="flex w-24 flex-col items-center">
            <div className="text-3xl">{podiumMeta[i].medal}</div>
            <div
              className={cn(
                "grid place-items-center rounded-full bg-white text-3xl shadow-lg ring-4",
                podiumMeta[i].ring,
                r.learnerId === me.id && "ring-brand-500",
              )}
              style={{ width: 60, height: 60 }}
            >
              {r.avatar}
            </div>
            <div className="mt-1 truncate text-sm font-bold text-ink">{r.name}</div>
            <div className="text-xs font-semibold text-brand-600">{fmt(r.xp)} XP</div>
            <div
              className={cn("mt-1 w-full rounded-t-2xl bg-gradient-to-t", i === 1 ? "from-sun-500 to-sun-300 h-32" : i === 0 ? "from-slate-400 to-slate-200 h-24" : "from-coral-500 to-coral-300 h-20")}
            />
          </div>
        ))}
      </div>

      {/* list */}
      <div className="card-soft divide-y divide-brand-50 overflow-hidden">
        {rows.map((r, i) => {
          const isMe = r.learnerId === me.id;
          return (
            <div
              key={r.learnerId}
              className={cn(
                "flex items-center gap-3 px-4 py-3",
                isMe && "bg-brand-50",
              )}
            >
              <span className="w-6 text-center font-display font-extrabold text-ink-soft">{i + 1}</span>
              <span className="grid h-10 w-10 place-items-center rounded-full bg-brand-100 text-xl">{r.avatar}</span>
              <div className="flex-1">
                <div className="font-bold text-ink">
                  {r.name} {isMe && <span className="text-xs text-brand-600">(أنت)</span>}
                </div>
                <div className="text-xs text-ink-soft">{r.lessonsCompleted} درس مكتمل</div>
              </div>
              <div className="flex items-center gap-1 font-display font-extrabold text-brand-600">
                ⭐ {fmt(r.xp)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
