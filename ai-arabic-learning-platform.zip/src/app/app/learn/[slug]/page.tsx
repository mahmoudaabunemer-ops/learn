import { notFound } from "next/navigation";
import { getLessons, getLearner } from "@/lib/data";
import { LessonPlayer } from "@/components/LessonPlayer";
import { lessonBySlug } from "@/lib/curriculum";

export const dynamic = "force-dynamic";

export default async function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [lessons, learner] = await Promise.all([getLessons(), getLearner()]);
  const lesson = lessons.find((l) => l.slug === slug) ?? lessonBySlug(slug) as never;

  if (!lesson || !lesson.exercises?.length) notFound();

  return (
    <LessonPlayer
      slug={lesson.slug}
      title={lesson.title}
      emoji={lesson.emoji}
      color={lesson.color}
      exercises={lesson.exercises}
      xpReward={lesson.xpReward}
      coinReward={lesson.coinReward}
      learnerId={learner.id}
    />
  );
}
