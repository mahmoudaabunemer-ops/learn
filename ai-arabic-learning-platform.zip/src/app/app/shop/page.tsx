import { getLearner } from "@/lib/data";
import { Shop } from "@/components/Shop";

export const dynamic = "force-dynamic";

export default async function ShopPage() {
  const learner = await getLearner();
  return <Shop coins={learner.coins} />;
}
