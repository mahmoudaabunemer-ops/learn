import Link from "next/link";
import { getLearner, getPerformanceStats, getEarnedAchievements } from "@/lib/data";
import { AnalysisCard, MiniBars } from "@/components/ParentDashboard";
import { Blobs } from "@/components/ui";
import { levelFromXp, rankTitle, fmt } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ParentPage() {
  const learner = await getLearner();
  const stats = await getPerformanceStats(learner.id);
  const badges = await getEarnedAchievements(learner.id);
  const lv = levelFromXp(learner.xp);

  const skills = [
    { label: "الحروف", pct: 92, color: "#7c3aed" },
    { label: "المفردات", pct: stats.best === "المفردات" ? 95 : 80, color: "#f59e0b" },
    { label: "القراءة", pct: 74, color: "#0ea5e9" },
    { label: "الإملاء", pct: stats.weakest === "الإملاء" ? 58 : 70, color: "#f43f5e" },
    { label: "النحو", pct: 66, color: "#14b8a6" },
    { label: "الاستماع", pct: 85, color: "#6366f1" },
  ];

  const week = [
    { d: "السبت", m: 12 },
    { d: "الأحد", m: 18 },
    { d: "الإثنين", m: 9 },
    { d: "الثلاثاء", m: 22 },
    { d: "الأربعاء", m: 15 },
    { d: "الخميس", m: 20 },
    { d: "الجمعة", m: learner.todayMinutes },
  ];
  const maxM = Math.max(...week.map((w) => w.m), 1);

  return (
    <div className="min-h-screen">
      <Blobs />
      <header className="sticky top-0 z-40 glass border-b border-white/50">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-coral-500 font-display text-xl font-extrabold text-white">ن</span>
            <span className="font-display text-lg font-extrabold text-ink">نون · ولي الأمر</span>
          </Link>
          <Link href="/app" className="btn-ghost !px-4 !py-2 text-sm">تجربة الطفل ←</Link>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-100 text-3xl ring-2 ring-brand-200">{learner.avatar}</span>
            <div>
              <h1 className="font-display text-2xl font-extrabold text-ink">{learner.name}</h1>
              <p className="text-sm text-ink-soft">المستوى {lv.level} · {rankTitle(lv.level)} · {learner.age} سنوات</p>
            </div>
          </div>
          <span className="chip bg-coral-400/10 text-coral-600">🔥 سلسلة {learner.streak} يوم</span>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { icon: "⏱️", v: `${fmt(learner.minutesLearned)} د`, l: "ساعات التعلّم", c: "text-brand-600" },
            { icon: "📚", v: learner.totalWordsLearned, l: "كلمات جديدة", c: "text-sun-600" },
            { icon: "✅", v: learner.lessonsCompleted, l: "دروس مكتملة", c: "text-mint-600" },
            { icon: "🎯", v: `${stats.accuracy}%`, l: "متوسط الدقة", c: "text-coral-600" },
          ].map((k) => (
            <div key={k.l} className="card-soft p-4">
              <div className="text-2xl">{k.icon}</div>
              <div className={`font-display mt-1 text-2xl font-extrabold ${k.c}`}>{k.v}</div>
              <div className="text-xs font-semibold text-ink-soft">{k.l}</div>
            </div>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* skills */}
          <div className="card-soft p-5">
            <h2 className="font-display text-lg font-extrabold text-ink">📊 مهارات اللغة</h2>
            <p className="mb-4 text-sm text-ink-soft">مستوى الإتقان في كل مجال</p>
            <MiniBars data={skills} />
          </div>

          {/* weekly activity */}
          <div className="card-soft p-5">
            <h2 className="font-display text-lg font-extrabold text-ink">📅 النشاط الأسبوعي</h2>
            <p className="mb-4 text-sm text-ink-soft">دقائق التعلّم اليومية</p>
            <div className="flex items-end justify-between gap-2" style={{ height: 160 }}>
              {week.map((w) => (
                <div key={w.d} className="flex flex-1 flex-col items-center gap-1">
                  <div className="text-[10px] font-bold text-brand-600">{w.m}</div>
                  <div className="w-full rounded-t-xl bg-gradient-to-t from-brand-500 to-mint-400" style={{ height: `${(w.m / maxM) * 100}%`, minHeight: 6 }} />
                  <div className="text-[10px] text-ink-soft">{w.d}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI analysis */}
        <AnalysisCard learnerId={learner.id} />

        {/* badges */}
        <div className="card-soft p-5">
          <h2 className="font-display text-lg font-extrabold text-ink">🏆 الشارات والإنجازات</h2>
          <div className="mt-4 flex flex-wrap gap-3">
            {(badges.length ? badges : FALLBACK_BADGES).map((b, i) => (
              <div key={i} className="flex w-28 flex-col items-center rounded-2xl bg-brand-50 p-3 text-center">
                <span className="text-3xl">{b.emoji}</span>
                <span className="mt-1 text-xs font-bold text-ink">{b.title}</span>
              </div>
            ))}
          </div>
        </div>

        {/* reports */}
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            { t: "تقرير أسبوعي", d: "ملخّص تقدّم الأسبوع", icon: "Weekly" },
            { t: "تقرير شهري", d: "تحليل شامل للشهر", icon: "Monthly" },
            { t: "توصيات AI", d: "خطة تعلّم شخصية", icon: "AI" },
          ].map((r) => (
            <button key={r.t} className="card-soft p-4 text-right transition hover:-translate-y-1">
              <div className="font-display font-bold text-brand-700">{r.t}</div>
              <div className="text-sm text-ink-soft">{r.d}</div>
            </button>
          ))}
        </div>
      </main>
    </div>
  );
}

const FALLBACK_BADGES = [
  { emoji: "🌟", title: "البداية الموفقة" },
  { emoji: "🔥", title: "سلسلة ٧ أيام" },
  { emoji: "📖", title: "قارئ صغير" },
  { emoji: "🏅", title: "٥٠ كلمة" },
];
